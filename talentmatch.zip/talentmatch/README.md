# TalentMatch

Resume–job matching and talent marketplace. Skills meet opportunity.

```
talentmatch/
├── README.md
├── frontend/                  everything the browser loads (no build step)
│   ├── index.html             landing page
│   ├── dashboard.html         candidate dashboard
│   ├── profile.html           resume upload + editable profile
│   ├── jobs.html, job.html    job search, filters, details + match score
│   ├── saved.html             saved jobs + application tracking
│   ├── skills.html            skill-gap analysis + career roadmap
│   ├── interview.html         interview practice
│   ├── recruiter*.html        recruiter overview, listings, post/edit job,
│   │                          ranked candidates, application management
│   ├── settings.html
│   └── assets/
│       ├── style.css          design system (colors, type, components)
│       └── app.js             matching engine, resume parser, UI, API client
└── backend/                   Java server (JDK only, no libraries)
    ├── run.sh / run.bat       compile + start
    ├── src/com/talentmatch/
    │   ├── Main.java              server setup and routes
    │   ├── StaticFileHandler.java serves ../frontend safely
    │   ├── StateHandler.java      GET/PUT /api/state
    │   ├── StateStore.java        atomic file persistence
    │   ├── JsonValidator.java     strict JSON syntax check
    │   ├── ResumeHandler.java     POST /api/resume/extract
    │   ├── DocxTextExtractor.java DOCX -> text
    │   └── Http.java              response/body helpers
    └── data/state.json        created on first save
```

## Run (recommended: frontend + backend together)

Requires JDK 11 or newer (check with `javac -version`).

```
cd backend
./run.sh          # Windows: run.bat
```

Open http://localhost:8080. The backend serves the frontend and stores data in
`backend/data/state.json`.

## Run the frontend only

No Java needed. From `frontend/` run `python3 -m http.server 8080`
(or open `index.html` directly). Data is then saved only in the browser.
The app detects whether the backend is present and switches automatically;
Settings shows which storage is in use.

## Backend API

| Method | Route | Purpose |
|---|---|---|
| GET | /api/health | liveness check |
| GET | /api/state | read saved state (`{}` if none) |
| PUT | /api/state | save state; valid JSON object, max 2 MB |
| POST | /api/resume/extract | raw file bytes in, `{"text": ...}` out; max 5 MB |

Resume extraction checks the file's real signature, not its name. DOCX and plain
text are handled by the backend; PDF and legacy DOC return 415 and the browser reads
PDFs itself (PDF.js). File contents are never logged or stored.

Configuration (environment variables): `PORT` (8080), `HOST` (127.0.0.1),
`FRONTEND_DIR` (../frontend), `DATA_DIR` (data).

## How matching works

Required skills 50%, preferred skills 15%, role and project relevance 15%,
experience 10%, education and certifications 10%. Skill names are normalised
through an alias map (JS = JavaScript). Factors with no data are left out and the
weights are rescaled; the score shows how much data it used. Rankings use a
priority queue, ties broken by required skills matched. Scores estimate alignment
with stated requirements; they do not predict hiring outcomes.

## Known limitations

- No authentication. Everyone who can reach the server sees the same state, which
  is why it binds to 127.0.0.1 by default. Do not expose it publicly without adding auth.
- One shared state document, not a multi-user database.
- Jobs and the talent pool are sample data, labelled as such.
- Matching and resume parsing run in the frontend; the backend does not recompute them.
- PDF extraction on the server needs Apache Tika or PDFBox: add the jar to the
  classpath and branch on the PDF signature in `ResumeHandler.java`.
