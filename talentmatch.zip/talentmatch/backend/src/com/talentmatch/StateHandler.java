package com.talentmatch;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;

/** GET /api/state returns the stored state; PUT /api/state replaces it (validated JSON object, max 2 MB). */
final class StateHandler implements HttpHandler {
    private static final int MAX_BYTES = 2 * 1024 * 1024;
    private final StateStore store;

    StateHandler(StateStore store) { this.store = store; }

    @Override
    public void handle(HttpExchange ex) throws IOException {
        try {
            String m = ex.getRequestMethod();
            if ("GET".equals(m) || "HEAD".equals(m)) {
                Http.json(ex, 200, store.read());
            } else if ("PUT".equals(m)) {
                byte[] body = Http.readBody(ex, MAX_BYTES);
                String text;
                try {
                    text = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(CodingErrorAction.REPORT)
                            .onUnmappableCharacter(CodingErrorAction.REPORT)
                            .decode(ByteBuffer.wrap(body)).toString();
                } catch (CharacterCodingException e) {
                    Http.error(ex, 400, "bad_encoding", "Body must be UTF-8 JSON.");
                    return;
                }
                if (!JsonValidator.isObject(text)) {
                    Http.error(ex, 400, "invalid_json", "Body must be a valid JSON object.");
                    return;
                }
                store.write(text);
                Http.json(ex, 200, "{\"saved\":true}");
            } else {
                ex.getResponseHeaders().set("Allow", "GET, PUT");
                Http.error(ex, 405, "method_not_allowed", "Use GET or PUT.");
            }
        } catch (Http.PayloadTooLarge e) {
            Http.error(ex, 413, "too_large", "State is larger than 2 MB.");
        } catch (Exception e) {
            System.err.println("[state] " + e.getClass().getSimpleName());
            Http.error(ex, 500, "server_error", "Something went wrong on the server.");
        }
    }
}
