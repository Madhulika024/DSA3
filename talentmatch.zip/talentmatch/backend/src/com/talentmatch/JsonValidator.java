package com.talentmatch;

/** Minimal strict JSON syntax checker (no external libraries). Accepts only a JSON object at the top level. */
final class JsonValidator {
    private final String s;
    private int i;

    private JsonValidator(String s) { this.s = s; }

    static boolean isObject(String text) {
        try {
            JsonValidator v = new JsonValidator(text);
            v.ws();
            if (v.i >= text.length() || text.charAt(v.i) != '{') return false;
            v.value(0);
            v.ws();
            return v.i == text.length();
        } catch (RuntimeException e) {
            return false;
        }
    }

    private void ws() { while (i < s.length() && " \t\r\n".indexOf(s.charAt(i)) >= 0) i++; }
    private char peek() { if (i >= s.length()) throw new IllegalStateException(); return s.charAt(i); }
    private void expect(char c) { if (peek() != c) throw new IllegalStateException(); i++; }

    private void value(int depth) {
        if (depth > 64) throw new IllegalStateException();
        ws();
        char c = peek();
        if (c == '{') {
            i++; ws();
            if (peek() == '}') { i++; return; }
            for (;;) {
                ws(); string(); ws(); expect(':'); value(depth + 1); ws();
                if (peek() == ',') { i++; continue; }
                expect('}'); return;
            }
        } else if (c == '[') {
            i++; ws();
            if (peek() == ']') { i++; return; }
            for (;;) {
                value(depth + 1); ws();
                if (peek() == ',') { i++; continue; }
                expect(']'); return;
            }
        } else if (c == '"') {
            string();
        } else if (s.startsWith("true", i)) { i += 4; }
        else if (s.startsWith("false", i)) { i += 5; }
        else if (s.startsWith("null", i)) { i += 4; }
        else number();
    }

    private void string() {
        expect('"');
        for (;;) {
            char c = peek(); i++;
            if (c == '"') return;
            if (c < 0x20) throw new IllegalStateException();
            if (c == '\\') {
                char e = peek(); i++;
                if (e == 'u') {
                    for (int k = 0; k < 4; k++) {
                        if (Character.digit(peek(), 16) < 0) throw new IllegalStateException();
                        i++;
                    }
                } else if ("\"\\/bfnrt".indexOf(e) < 0) throw new IllegalStateException();
            }
        }
    }

    private void number() {
        int start = i;
        if (peek() == '-') i++;
        if (peek() == '0') i++;
        else if (peek() >= '1' && peek() <= '9') { while (i < s.length() && Character.isDigit(s.charAt(i))) i++; }
        else throw new IllegalStateException();
        if (i < s.length() && s.charAt(i) == '.') {
            i++;
            int d = i;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            if (i == d) throw new IllegalStateException();
        }
        if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
            i++;
            if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
            int d = i;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            if (i == d) throw new IllegalStateException();
        }
        if (i == start) throw new IllegalStateException();
    }
}
