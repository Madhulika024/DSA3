package com.talentmatch;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Serves the frontend folder. Blocks path traversal, dotfiles, and symlinks that leave the folder. */
final class StaticFileHandler implements HttpHandler {
    private static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put("html", "text/html; charset=utf-8");
        MIME.put("css", "text/css; charset=utf-8");
        MIME.put("js", "text/javascript; charset=utf-8");
        MIME.put("json", "application/json; charset=utf-8");
        MIME.put("svg", "image/svg+xml");
        MIME.put("png", "image/png");
        MIME.put("jpg", "image/jpeg");
        MIME.put("ico", "image/x-icon");
        MIME.put("txt", "text/plain; charset=utf-8");
        MIME.put("woff2", "font/woff2");
    }

    private final Path root;

    StaticFileHandler(Path root) throws IOException { this.root = root.toRealPath(); }

    @Override
    public void handle(HttpExchange ex) throws IOException {
        try {
            String raw = ex.getRequestURI().getRawPath();
            if (raw.startsWith("/api/")) {
                Http.error(ex, 404, "not_found", "Unknown API route.");
                return;
            }
            String m = ex.getRequestMethod();
            if (!"GET".equals(m) && !"HEAD".equals(m)) {
                ex.getResponseHeaders().set("Allow", "GET, HEAD");
                Http.error(ex, 405, "method_not_allowed", "Use GET.");
                return;
            }
            String p = URLDecoder.decode(raw, "UTF-8");
            if (p.indexOf('\0') >= 0) { Http.error(ex, 400, "bad_request", "Bad path."); return; }
            if (p.equals("/")) p = "/index.html";
            Path f = root.resolve(p.substring(1)).normalize();
            if (!f.startsWith(root) || !Files.isRegularFile(f)) { notFound(ex); return; }
            Path real = f.toRealPath();
            if (!real.startsWith(root)) { notFound(ex); return; }
            for (Path part : root.relativize(real)) {
                if (part.toString().startsWith(".")) { notFound(ex); return; }
            }
            String name = real.getFileName().toString();
            int dot = name.lastIndexOf('.');
            String type = dot >= 0 ? MIME.getOrDefault(name.substring(dot + 1).toLowerCase(), "application/octet-stream") : "application/octet-stream";
            Http.send(ex, 200, type, Files.readAllBytes(real), "no-cache");
        } catch (Exception e) {
            System.err.println("[static] " + e.getClass().getSimpleName());
            Http.error(ex, 500, "server_error", "Something went wrong on the server.");
        }
    }

    private void notFound(HttpExchange ex) throws IOException {
        byte[] body = "<!doctype html><title>Not found</title><h1>404</h1><p>That page doesn't exist. <a href=\"/\">Go home</a></p>".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        Http.send(ex, 404, "text/html; charset=utf-8", body, "no-cache");
    }
}
