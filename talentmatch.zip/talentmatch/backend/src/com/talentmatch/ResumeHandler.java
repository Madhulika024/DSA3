package com.talentmatch;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;

/**
 * POST /api/resume/extract : raw file bytes in, {"text": "..."} out.
 * File type is decided from the file's magic bytes, not its name. Contents are never logged or stored.
 * DOCX and plain text are handled here. PDF and legacy DOC need a library such as Apache Tika
 * (see backend/README.md); for those the server answers 415 and the browser falls back to its own reader.
 */
final class ResumeHandler implements HttpHandler {
    private static final int MAX_BYTES = 5 * 1024 * 1024;

    @Override
    public void handle(HttpExchange ex) throws IOException {
        try {
            if (!"POST".equals(ex.getRequestMethod())) {
                ex.getResponseHeaders().set("Allow", "POST");
                Http.error(ex, 405, "method_not_allowed", "Use POST.");
                return;
            }
            byte[] b = Http.readBody(ex, MAX_BYTES);
            if (b.length < 100) {
                Http.error(ex, 400, "empty_file", "The file is empty or too small to be a resume.");
                return;
            }
            String text;
            String source;
            if (b[0] == '%' && b[1] == 'P' && b[2] == 'D' && b[3] == 'F') {
                Http.error(ex, 415, "pdf_not_supported", "PDF extraction needs Apache Tika on the server. The browser will read this PDF instead.");
                return;
            } else if ((b[0] & 0xFF) == 0xD0 && (b[1] & 0xFF) == 0xCF) {
                Http.error(ex, 415, "doc_not_supported", "Legacy .doc files are not supported. Save as DOCX or PDF.");
                return;
            } else if (b[0] == 'P' && b[1] == 'K') {
                try {
                    text = DocxTextExtractor.extract(b);
                } catch (IOException e) {
                    Http.error(ex, 422, "unreadable", "The document could not be read. It may be corrupted.");
                    return;
                }
                source = "docx";
            } else if (looksLikeText(b)) {
                try {
                    text = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(CodingErrorAction.REPORT)
                            .decode(ByteBuffer.wrap(b)).toString();
                } catch (CharacterCodingException e) {
                    Http.error(ex, 415, "unsupported", "Unsupported file type.");
                    return;
                }
                source = "text";
            } else {
                Http.error(ex, 415, "unsupported", "Unsupported file type. Upload a PDF, DOC, or DOCX file.");
                return;
            }
            if (text.replaceAll("\\s", "").length() < 40) {
                Http.error(ex, 422, "no_text", "No readable text was found in this file.");
                return;
            }
            Http.json(ex, 200, "{\"source\":\"" + source + "\",\"chars\":" + text.length() + ",\"text\":\"" + Http.esc(text) + "\"}");
        } catch (Http.PayloadTooLarge e) {
            Http.error(ex, 413, "too_large", "Files must be 5 MB or smaller.");
        } catch (Exception e) {
            System.err.println("[resume] " + e.getClass().getSimpleName());
            Http.error(ex, 500, "server_error", "Something went wrong on the server.");
        }
    }

    private static boolean looksLikeText(byte[] b) {
        int n = Math.min(b.length, 1000);
        for (int i = 0; i < n; i++) if (b[i] == 0) return false;
        return true;
    }
}
