package com.talentmatch;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Extracts plain text from a .docx (an OOXML zip) using only the JDK. */
final class DocxTextExtractor {
    private static final long MAX_XML_BYTES = 10L * 1024 * 1024; // guards against zip bombs

    private DocxTextExtractor() {}

    static String extract(byte[] data) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                if ("word/document.xml".equals(e.getName())) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    long total = 0;
                    int n;
                    while ((n = zip.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_XML_BYTES) throw new IOException("Document too large");
                        out.write(buf, 0, n);
                    }
                    return toText(new String(out.toByteArray(), StandardCharsets.UTF_8));
                }
            }
        }
        throw new IOException("Not a Word document");
    }

    static String toText(String xml) {
        String t = xml
                .replaceAll("<w:tab\\s*/>", "\t")
                .replaceAll("<w:br\\s*/>", "\n")
                .replaceAll("</w:p>", "\n")
                .replaceAll("<[^>]+>", "")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
        return t.replaceAll("[ \\t]+\\n", "\n").replaceAll("\\n{3,}", "\n\n").trim();
    }
}
