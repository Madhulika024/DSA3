package com.talentmatch;

import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.Executors;

/**
 * TalentMatch backend: serves the frontend and exposes a small JSON API.
 *   GET  /api/health          liveness check
 *   GET  /api/state           read saved application state
 *   PUT  /api/state           save application state (JSON object, max 2 MB)
 *   POST /api/resume/extract  text extraction from DOCX/plain text (max 5 MB)
 * Configuration (environment variables): PORT=8080, HOST=127.0.0.1, FRONTEND_DIR=../frontend, DATA_DIR=data
 */
public final class Main {
    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(env("PORT", "8080"));
        String host = env("HOST", "127.0.0.1");
        Path frontend = Paths.get(env("FRONTEND_DIR", "../frontend")).toAbsolutePath().normalize();
        Path data = Paths.get(env("DATA_DIR", "data")).toAbsolutePath().normalize();

        if (!Files.isDirectory(frontend)) {
            System.err.println("Frontend folder not found: " + frontend);
            System.err.println("Run from the backend folder, or set FRONTEND_DIR.");
            System.exit(1);
        }
        Files.createDirectories(data);

        HttpServer server = HttpServer.create(new InetSocketAddress(host, port), 0);
        StateStore store = new StateStore(data.resolve("state.json"));
        server.createContext("/api/health", ex -> Http.json(ex, 200, "{\"status\":\"ok\"}"));
        server.createContext("/api/state", new StateHandler(store));
        server.createContext("/api/resume/extract", new ResumeHandler());
        server.createContext("/", new StaticFileHandler(frontend));
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();

        System.out.println("TalentMatch is running at http://" + host + ":" + port + "/");
        System.out.println("Frontend: " + frontend);
        System.out.println("Data:     " + data.resolve("state.json"));
        System.out.println("Press Ctrl+C to stop.");
    }

    private static String env(String key, String fallback) {
        String v = System.getenv(key);
        return v == null || v.trim().isEmpty() ? fallback : v.trim();
    }
}
