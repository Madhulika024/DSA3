package com.talentmatch;

import com.sun.net.httpserver.HttpExchange;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Small helpers shared by all handlers. */
final class Http {
    private Http() {}

    /** Thrown when a request body exceeds the allowed size. */
    static final class PayloadTooLarge extends IOException {
        private static final long serialVersionUID = 1L;
        PayloadTooLarge() { super("Payload too large"); }
    }

    static void send(HttpExchange ex, int status, String contentType, byte[] body, String cache) throws IOException {
        ex.getResponseHeaders().set("Content-Type", contentType);
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        ex.getResponseHeaders().set("Referrer-Policy", "no-referrer");
        ex.getResponseHeaders().set("Cache-Control", cache);
        if ("HEAD".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(status, -1);
            ex.close();
            return;
        }
        ex.sendResponseHeaders(status, body.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(body);
        }
    }

    static void json(HttpExchange ex, int status, String json) throws IOException {
        send(ex, status, "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8), "no-store");
    }

    static void error(HttpExchange ex, int status, String code, String message) throws IOException {
        json(ex, status, "{\"error\":\"" + esc(code) + "\",\"message\":\"" + esc(message) + "\"}");
    }

    /** Reads at most {@code max} bytes, otherwise throws PayloadTooLarge. */
    static byte[] readBody(HttpExchange ex, int max) throws IOException {
        String len = ex.getRequestHeaders().getFirst("Content-Length");
        if (len != null) {
            try {
                if (Long.parseLong(len.trim()) > max) throw new PayloadTooLarge();
            } catch (NumberFormatException ignored) { /* checked while reading */ }
        }
        try (InputStream in = ex.getRequestBody()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > max) throw new PayloadTooLarge();
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.toString();
    }
}
