@echo off
rem Compiles and starts the TalentMatch backend (needs JDK 11 or newer).
cd /d "%~dp0"
if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt || exit /b 1
del sources.txt
java -cp out com.talentmatch.Main
