#!/usr/bin/env sh
# Compiles and starts the TalentMatch backend (needs JDK 11 or newer).
set -e
cd "$(dirname "$0")"
mkdir -p out
javac -d out $(find src -name '*.java')
exec java -cp out com.talentmatch.Main
