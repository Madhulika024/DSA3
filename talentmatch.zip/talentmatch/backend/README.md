# TalentMatch backend

Plain Java (JDK 11+), built on `com.sun.net.httpserver`. No Maven, no dependencies.

    ./run.sh        # macOS/Linux
    run.bat         # Windows

Starts on http://127.0.0.1:8080, serves ../frontend, and exposes /api/*.
See the root README for the API and configuration.
