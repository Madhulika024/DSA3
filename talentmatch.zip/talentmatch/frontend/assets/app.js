(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Math.random().toString(36).slice(2,9);
const ICONS={upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',file:'<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/>',briefcase:'<rect width="20" height="14" x="2" y="7" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',bookmark:'<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>',check:'<path d="M20 6 9 17l-5-5"/>',x:'<path d="M18 6 6 18M6 6l12 12"/>',bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',pin:'<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',plus:'<path d="M5 12h14M12 5v14"/>',target:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',sliders:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',trend:'<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',cap:'<path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>',users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',chat:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',alert:'<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',pencil:'<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',route:'<circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/>',send:'<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',lock:'<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>'};
const ic=(n,s=16)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n]||''}</svg>`;

//#ENGINE-START
const SK=[['javascript','JavaScript',['js','ecmascript','es6']],['typescript','TypeScript'],['java','Java',['core java','java se']],['python','Python',['python3']],['c++','C++',['cpp']],['c#','C#',['csharp','c sharp']],['kotlin','Kotlin'],['swift','Swift'],
['sql','SQL',['mysql','postgresql','postgres','sqlite','sql server','mssql','t-sql','pl/sql']],['html','HTML',['html5']],['css','CSS',['css3','scss','sass']],['react','React',['react.js','reactjs','react js']],['angular','Angular',['angularjs']],['vue','Vue',['vue.js','vuejs']],
['node.js','Node.js',['nodejs','node js','node']],['express','Express',['express.js','expressjs']],['spring boot','Spring Boot',['springboot','spring-boot']],['django','Django'],['flask','Flask'],['rest','REST',['rest api','rest apis','restful','restful api','restful apis']],['graphql','GraphQL'],['mongodb','MongoDB',['mongo']],['redis','Redis'],
['docker','Docker'],['kubernetes','Kubernetes',['k8s']],['aws','AWS',['amazon web services']],['azure','Azure',['microsoft azure']],['gcp','GCP',['google cloud','google cloud platform']],['linux','Linux',['unix']],['git','Git',['github','gitlab','version control']],['ci/cd','CI/CD',['cicd','ci cd','continuous integration','github actions']],
['jenkins','Jenkins'],['terraform','Terraform'],['kafka','Kafka',['apache kafka']],['spark','Spark',['apache spark','pyspark']],['etl','ETL',['data pipelines']],['pandas','Pandas'],['numpy','NumPy'],['tensorflow','TensorFlow'],['pytorch','PyTorch'],['machine learning','Machine Learning',['ml']],['deep learning','Deep Learning'],['nlp','NLP',['natural language processing']],
['statistics','Statistics',['statistical analysis']],['excel','Excel',['ms excel','microsoft excel','advanced excel']],['tableau','Tableau'],['power bi','Power BI',['powerbi']],['analytics','Analytics',['data analysis','data analytics']],['figma','Figma'],['prototyping','Prototyping',['wireframing']],['ux research','UX Research',['user research']],
['selenium','Selenium'],['testing','Testing',['unit testing','test automation','manual testing']],['jest','Jest'],['networking','Networking',['computer networks','tcp/ip']],['security','Security',['cybersecurity','cyber security','information security']],['android','Android',['android development','android sdk']],['tailwind','Tailwind',['tailwind css','tailwindcss']],
['data structures','Data Structures',['dsa','data structures and algorithms']],['algorithms','Algorithms'],['agile','Agile',['scrum']]];
const GENERIC=new Set(['rest','express','spark','testing','analytics','security','networking','statistics']);
const ALIAS={},DISP={},RX={};
SK.forEach(([k,d,al=[]])=>{ALIAS[k]=k;DISP[k]=d;al.forEach(a=>ALIAS[a]=k);
 const forms=GENERIC.has(k)?al:[k,...al];
 if(forms.length)RX[k]=new RegExp('(?<![A-Za-z0-9+#])(?:'+forms.map(f=>f.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&')).join('|')+')(?![A-Za-z0-9+#])','i');});
function canon(s){let t=String(s||'').toLowerCase().trim().replace(/[()]/g,' ').replace(/\s+/g,' ').replace(/^[^a-z0-9.+#]+|[.,;:!]+$/g,'');return ALIAS[t]||ALIAS[t.replace(/[-_]/g,' ')]||t.replace(/[-_]/g,' ');}
const disp=k=>DISP[k]||String(k).replace(/\b\w/g,c=>c.toUpperCase());
function findSkills(text){const t=String(text||'');return Object.keys(RX).filter(k=>RX[k].test(t));}
const WEIGHTS={req:.5,pref:.15,role:.15,exp:.10,edu:.10};
const EDU_RANK={any:0,diploma:1,bachelor:2,master:3,phd:4};
function eduRank(q){const t=String(q||'').toLowerCase();if(!t.trim())return null;if(/ph\.?d|doctor/.test(t))return 4;if(/\bm\.?\s?(tech|sc|ca|e|s|com|a)\b|master|\bmba\b|post.?grad/.test(t))return 3;if(/\bb\.?\s?(tech|e|sc|ca|com|a|des|s)\b|bachelor|undergrad|\bbe\b/.test(t))return 2;if(/diploma|polytechnic/.test(t))return 1;return 2;}
const STOP=new Set(['the','a','an','of','and','for','junior','senior','associate','intern','jr','sr','i','ii']);
function titleTokens(s){let t=String(s||'').toLowerCase().replace(/front[\s-]?end/g,'frontend').replace(/back[\s-]?end/g,'backend').replace(/full[\s-]?stack/g,'fullstack').split(/[^a-z0-9]+/).filter(x=>x&&!STOP.has(x)).map(x=>x==='programmer'?'engineer':x==='developer'?'engineer':x);const set=new Set(t);if(set.size>1)set.delete('engineer');return set;}
function bandOf(s){return s==null?{label:'Not enough data',cls:'b-dev'}:s>=75?{label:'Strong match',cls:'b-strong'}:s>=55?{label:'Good match',cls:'b-good'}:{label:'Developing match',cls:'b-dev'};}
function scoreMatch(c,job){
 const cs=new Set((c.skills||[]).map(canon).filter(Boolean));
 const req=[...new Set((job.req||[]).map(canon))],pref=[...new Set((job.pref||[]).map(canon))];
 const none={score:null,reason:'Add skills to your profile to see a score.',comps:[],matchedReq:[],missingReq:req.map(disp),matchedPref:[],missingPref:pref.map(disp),relProjects:[],confidence:0,notes:[],explain:[]};
 if(!cs.size||!req.length)return none;
 const mReq=req.filter(k=>cs.has(k)),xReq=req.filter(k=>!cs.has(k)),mPref=pref.filter(k=>cs.has(k)),xPref=pref.filter(k=>!cs.has(k));
 const comps=[];
 comps.push({key:'req',label:'Required skills',w:WEIGHTS.req,v:100*mReq.length/req.length,known:true,note:`${mReq.length} of ${req.length} required skills`});
 if(pref.length)comps.push({key:'pref',label:'Preferred skills',w:WEIGHTS.pref,v:100*mPref.length/pref.length,known:true,note:`${mPref.length} of ${pref.length} preferred skills`});
 // role + project relevance
 const parts=[],jt=titleTokens(job.title),ct=titleTokens((c.role||'')+' '+(c.prefRole||''));
 const projArr=(Array.isArray(c.projects)?c.projects:String(c.projects||'').split('\n')).filter(x=>String(x).trim());
 const projText=projArr.join('\n'),projSk=new Set(findSkills(projText).concat(projText.trim()?[...cs].filter(k=>GENERIC.has(k)&&RX[k]&&RX[k].test(projText)):[]));
 const relProjects=projArr.filter(p=>req.some(k=>findSkills(p).includes(k)));
 let roleNote=[];
 if(ct.size&&jt.size){const inter=[...jt].filter(t=>ct.has(t)).length;parts.push(100*inter/jt.size);roleNote.push(inter?'role title overlaps with the job':'role title differs from the job');}
 if(projArr.length){const hit=req.filter(k=>projSk.has(k)).length;parts.push(100*hit/req.length);roleNote.push(`projects mention ${hit} of ${req.length} required skills`);}
 comps.push({key:'role',label:'Role & project relevance',w:WEIGHTS.role,v:parts.length?parts.reduce((a,b)=>a+b,0)/parts.length:0,known:parts.length>0,note:parts.length?roleNote.join('; '):'No role or projects provided'});
 const exp=c.exp===''||c.exp==null||isNaN(+c.exp)?null:+c.exp,need=+job.expMin||0;
 comps.push({key:'exp',label:'Experience',w:WEIGHTS.exp,v:exp==null?0:(need===0?100:Math.min(100,100*exp/need)),known:exp!=null,note:exp==null?'Experience not provided':`${exp} yr${exp===1?'':'s'} vs ${need} required`});
 const cr=eduRank(c.qualification),jr=EDU_RANK[String(job.edu||'any').toLowerCase()]??0;
 let ev=0,en='Qualification not provided';
 if(cr!=null){ev=jr===0?100:Math.min(100,100*cr/jr);const cert=findSkills((Array.isArray(c.certs)?c.certs.join(' '):c.certs)||'').filter(k=>req.includes(k)||pref.includes(k));if(cert.length&&ev<100){ev=Math.min(100,ev+10);}en=cr>=jr?'Meets education requirement':'Below stated education level';if(cert.length)en+='; relevant certification';}
 comps.push({key:'edu',label:'Education & certifications',w:WEIGHTS.edu,v:ev,known:cr!=null,note:en});
 const known=comps.filter(x=>x.known),sw=known.reduce((a,x)=>a+x.w,0),all=comps.reduce((a,x)=>a+x.w,0);
 const score=Math.round(known.reduce((a,x)=>a+x.w*x.v,0)/sw);
 comps.forEach(x=>{x.share=x.known?Math.round(100*x.w/sw):0;x.v=Math.round(x.v)});
 const conf=Math.round(100*sw/all);
 const notes=[];if(conf<100)notes.push(`Based on ${known.length} of ${comps.length} factors. Missing: ${comps.filter(x=>!x.known).map(x=>x.label.toLowerCase()).join(', ')}.`);
 const explain=[];
 explain.push(mReq.length===req.length?'You list every required skill.':mReq.length?`You cover ${mReq.length} of ${req.length} required skills.`:'None of the required skills appear in your profile yet.');
 if(xReq.length)explain.push(`Missing required: ${xReq.map(disp).join(', ')}.`);
 if(relProjects.length)explain.push(`${relProjects.length} of your projects use required skills.`);
 comps.filter(x=>!x.known).forEach(x=>explain.push(`${x.label} not scored — add it to your profile to improve accuracy.`));
 return{score,comps,matchedReq:mReq.map(disp),missingReq:xReq.map(disp),matchedPref:mPref.map(disp),missingPref:xPref.map(disp),relProjects,confidence:conf,notes,explain,reason:''};}
// binary min-heap keyed by comparator: cmp(a,b)>0 means a ranks higher
class Heap{constructor(c){this.a=[];this.c=c}get size(){return this.a.length}
 push(x){const a=this.a;a.push(x);let i=a.length-1;while(i>0){const p=(i-1)>>1;if(this.c(a[i],a[p])<0){[a[i],a[p]]=[a[p],a[i]];i=p}else break}}
 pop(){const a=this.a;if(!a.length)return;const t=a[0],l=a.pop();if(a.length){a[0]=l;let i=0;for(;;){let m=i,L=2*i+1,R=L+1;if(L<a.length&&this.c(a[L],a[m])<0)m=L;if(R<a.length&&this.c(a[R],a[m])<0)m=R;if(m===i)break;[a[i],a[m]]=[a[m],a[i]];i=m}}return t}}
function topK(items,k,cmp){const h=new Heap(cmp);for(const x of items){h.push(x);if(h.size>k)h.pop();}const out=[];while(h.size)out.push(h.pop());return out.reverse();}
const rankCmp=(a,b)=>{const sa=a.m.score==null?-1:a.m.score,sb=b.m.score==null?-1:b.m.score;if(sa!==sb)return sa-sb;if(a.m.matchedReq.length!==b.m.matchedReq.length)return a.m.matchedReq.length-b.m.matchedReq.length;return String(b.key).localeCompare(String(a.key));};
//#ENGINE-END

//#PARSER-START
const CITIES=['Hyderabad','Bengaluru','Bangalore','Chennai','Mumbai','Pune','New Delhi','Delhi','Noida','Gurgaon','Gurugram','Kolkata','Ahmedabad','Kochi','Jaipur','Visakhapatnam','Coimbatore','London','New York','San Francisco','Toronto','Singapore','Dubai','Berlin'];
const SEC=/^(technical skills|skills|core competencies|key skills|education|academic(?: background| qualifications)?|academic projects|personal projects|projects?|certifications?|certificates|licenses(?: & certifications)?|work experience|professional experience|experience|internships?|summary|professional summary|objective|career objective|profile|achievements|interests|languages|references)\s*:?$/i;
function secKey(l){const t=l.trim().toLowerCase().replace(/:$/,'');if(/skill|competenc/.test(t))return'skills';if(/educ|academic (?:back|qual)/.test(t))return'edu';if(/project/.test(t))return'projects';if(/certif|licens/.test(t))return'certs';if(/experience|internship/.test(t))return'exp';return'other';}
function parseResume(raw){
 const text=String(raw||'').replace(/\r/g,'').replace(/[\u00a0\t]+/g,' ');
 const lines=text.split('\n').map(l=>l.trim()).filter(Boolean);
 const secs={};let cur='top';secs.top=[];
 for(const l of lines){if(l.length<=40&&SEC.test(l)){cur=secKey(l);secs[cur]=secs[cur]||[];continue}(secs[cur]=secs[cur]||[]).push(l);}
 const f={};
 const em=text.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);if(em)f.email=em[0];
 for(const m of text.matchAll(/(\+?\d[\d\s().-]{8,16}\d)/g)){const d=m[1].replace(/\D/g,'');if(d.length>=10&&d.length<=13&&!/^(19|20)\d{2}\s*[-–]/.test(m[1])){f.phone=m[1].trim();break}}
 const head=lines.slice(0,8);
 const bad=/@|\d|resume|curriculum|vitae|developer|engineer|analyst|designer|scientist|student|intern|manager|summary|objective|profile|skills|education/i;
 for(const l of head){const w=l.split(/\s+/);if(w.length>=2&&w.length<=4&&w.every(x=>/^[A-Za-z.'-]+$/.test(x))&&!bad.test(l)&&l.length<40){f.name=l===l.toUpperCase()?l.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()):l;break}}
 for(const l of head){if(/(developer|engineer|analyst|designer|scientist|architect|administrator|consultant|manager)/i.test(l)&&l.length<=60&&!/@/.test(l)&&l!==f.name){f.role=l.replace(/^[•\-*|\s]+|[|•\s]+$/g,'');break}}
 const lm=text.match(/(?:location|address|city)\s*[:\-]\s*([^\n|]{3,60})/i);
 if(lm)f.location=lm[1].trim();else{const hs=head.join(' | ');for(const c of CITIES){const m=hs.match(new RegExp('\\b'+c+'\\b(?:\\s*,\\s*[A-Z][A-Za-z ]{2,20})?'));if(m){f.location=m[0].trim();break}}}
 const eduLines=(secs.edu&&secs.edu.length?secs.edu:lines);
 const longQ=/(Bachelor(?:'s)?(?: of| in)? [A-Za-z ]{3,40}|Master(?:'s)?(?: of| in)? [A-Za-z ]{3,40}|Ph\.?D|Diploma(?: in [A-Za-z ]{3,40})?)/i,shortQ=/\b(B\.?\s?Tech|B\.E\.?|BE|B\.?Sc|BCA|MCA|M\.?Tech|M\.?Sc|M\.E\.?|B\.?Com|MBA|B\.?Des|PhD)\b/;
 let qline=null;
 for(const l of eduLines){const m=l.match(shortQ)||l.match(longQ);if(m){f.qualification=m[0].replace(/\s+/g,' ').trim();qline=l;
  const after=l.slice(l.indexOf(m[0])+m[0].length);
  const sp=after.match(/^[\s,()\-–:]*(?:in\s+)?([A-Za-z&\s]{4,50}?)(?=[,|(\n]|\s[-–]\s|\s\d{4}|\s(?:from|at)\b|$)/);
  if(sp&&/(computer|information|electronic|electrical|mechanical|civil|data|software|science|technology|engineering|business|math|statistic|artificial|cyber|design)/i.test(sp[1]))f.specialization=sp[1].trim();
  else if(/^(Bachelor|Master)/i.test(m[0])){const q=m[0].match(/(?:of|in)\s+(.+)$/i);if(q)f.specialization=q[1].trim();}
  break}}
 for(const l of eduLines){if(/(university|college|institute|\biit\b|\bnit\b|\biiit\b|school of)/i.test(l)&&l.length<=110){const seg=l.split(/[,|]/).map(x=>x.trim()).filter(x=>/(university|college|institute|\biit\b|\bnit\b|\biiit\b|school of)/i.test(x));f.college=(seg[0]||l).replace(/^[•\-*\s]+/,'').replace(/\s*[|–-]\s*\d.*$/,'').replace(/,?\s*(?:CGPA|GPA|\d{4}).*$/i,'').trim();break}}
 const yrs=[...eduLines.join(' ').matchAll(/\b(19\d\d|20[0-3]\d)\b/g)].map(m=>+m[1]);if(yrs.length&&(secs.edu&&secs.edu.length))f.gradYear=String(Math.max(...yrs));
 const ey=text.match(/(\d{1,2}(?:\.\d)?)\+?\s*(?:years?|yrs?)\b(?:\s+of)?\s+(?:professional\s+|industry\s+|relevant\s+)?(?:experience|exp)/i);
 if(ey)f.exp=ey[1];else if(secs.exp&&secs.exp.length){const rs=[...secs.exp.join(' ').matchAll(/((?:19|20)\d\d)\s*(?:-|–|to)\s*((?:19|20)\d\d|present|current)/gi)];if(rs.length){const now=new Date().getFullYear();let tot=0;rs.forEach(r=>{const s=+r[1],e=/^\d/.test(r[2])?+r[2]:now;if(e>=s)tot+=e-s});if(tot>0)f.exp=String(tot)}}
 const skills=new Set(findSkills(text).map(disp));
 (secs.skills||[]).forEach(l=>{l.replace(/^[^:]{2,30}:/,'').split(/[,;|•·●▪]/).forEach(t=>{t=t.trim().replace(/^[-*]\s*/,'');if(t&&t.length<=28&&t.split(/\s+/).length<=3&&!/[.!?]$/.test(t)){const k=canon(t);skills.add(DISP[k]||t)}})});
 if(skills.size)f.skills=[...skills];
 const bul=/^[•\-*▪●·]\s*/;
 const items=(arr,max)=>{const out=[],titled=(arr||[]).some(l=>!bul.test(l));for(const l of arr||[]){if(titled&&bul.test(l)&&out.length){out[out.length-1]+=' '+l.replace(bul,'')}else out.push(l.replace(bul,''))}return out.map(x=>x.slice(0,240)).filter(x=>x.length>8).slice(0,max)};
 const pr=items(secs.projects,6);if(pr.length)f.projects=pr;
 const ce=(secs.certs||[]).map(l=>l.replace(bul,'').slice(0,120)).filter(x=>x.length>4).slice(0,8);if(ce.length)f.certs=ce;
 return{fields:f,count:Object.keys(f).length,chars:text.length};}
//#PARSER-END

// ------------- data
const KEY='talentmatch.v1';
const day=86400000;
const J=(id,title,company,location,mode,type,expMin,edu,req,pref,desc,resp,quals,ago)=>({id,title,company,location,mode,type,expMin,edu,req,pref,desc,resp,quals,apply:'Apply through TalentMatch. Shortlisted candidates are contacted by email.',posted:Date.now()-ago*day,published:true,sample:true});
function seedJobs(){return[
J('j1','Frontend Developer','Northwind Labs','Hyderabad','Hybrid','Full-time',1,'Bachelor',['JavaScript','React','HTML','CSS','Git'],['TypeScript','Tailwind','Jest'],'Build responsive customer-facing web interfaces for a logistics analytics product. You will work with designers and backend engineers to ship features every two weeks.',['Build reusable React components','Turn designs into accessible, responsive pages','Write unit tests for UI logic','Review pull requests and fix production bugs'],['Bachelor’s degree in Computer Science or related field','Portfolio or projects using React'],2),
J('j2','Java Backend Developer','Lumen Systems','Bengaluru','On-site','Full-time',2,'Bachelor',['Java','Spring Boot','SQL','REST','Git'],['Docker','AWS','Kafka'],'Design and maintain REST services that power billing for a B2B payments platform.',['Design REST APIs with Spring Boot','Model and query relational data','Write integration tests','Support production incidents'],['2+ years building Java services','Understanding of transactions and API design'],5),
J('j3','Data Analyst','Brightpath Analytics','Hyderabad','Hybrid','Full-time',0,'Bachelor',['SQL','Excel','Python','Tableau'],['Statistics','Power BI'],'Turn operational data into weekly dashboards and ad-hoc analyses for retail clients.',['Write SQL to answer business questions','Build Tableau dashboards','Clean and validate datasets with Python','Present findings to stakeholders'],['Degree in a quantitative field','Strong Excel skills'],1),
J('j4','Machine Learning Engineer','Orbital AI','Remote','Remote','Full-time',2,'Master',['Python','Machine Learning','TensorFlow','Pandas','SQL'],['PyTorch','Docker','Statistics'],'Train and ship recommendation models for a streaming platform.',['Prepare and validate training data','Train and evaluate models','Deploy models behind internal APIs','Monitor model quality'],['Master’s degree or equivalent experience','Experience shipping ML to production'],7),
J('j5','Full Stack Developer','Kitebridge','Pune','Hybrid','Full-time',1,'Bachelor',['JavaScript','Node.js','React','MongoDB','REST'],['TypeScript','Docker','Git'],'Own features end to end across a React front end and a Node.js API for a SaaS scheduling tool.',['Build features across UI and API','Design MongoDB schemas','Write REST endpoints','Deploy with CI pipelines'],['Projects across front end and back end','Comfort with debugging across the stack'],3),
J('j6','DevOps Engineer','Stackhaven','Bengaluru','Hybrid','Full-time',3,'Bachelor',['Linux','Docker','Kubernetes','CI/CD','AWS','Git'],['Terraform','Jenkins'],'Run the build, release, and cloud infrastructure for a fintech platform.',['Maintain CI/CD pipelines','Operate Kubernetes clusters','Automate cloud infrastructure','Respond to on-call incidents'],['3+ years in infrastructure or SRE','Hands-on AWS experience'],9),
J('j7','UI/UX Designer','Plainfield Studio','Mumbai','On-site','Full-time',1,'Bachelor',['Figma','UX Research','Prototyping','HTML','CSS'],['Agile'],'Design web and mobile experiences for healthcare booking products.',['Run user interviews','Create flows and prototypes in Figma','Hand off specs to engineers','Test designs with users'],['Portfolio with case studies','Understanding of accessibility'],4),
J('j8','QA Automation Engineer','Clearpoint Software','Chennai','Hybrid','Full-time',1,'Bachelor',['Selenium','Java','Testing','SQL','Git'],['Jenkins','CI/CD'],'Build automated regression suites for an insurance claims platform.',['Write Selenium test suites','Validate data with SQL','Triage failures','Integrate tests in CI'],['Experience with test automation frameworks'],6),
J('j9','Android Developer','Pocketwise','Bengaluru','Hybrid','Full-time',1,'Bachelor',['Kotlin','Android','Java','REST','Git'],['Jest','Agile'],'Build features for a personal finance app used by two million people.',['Build screens with Kotlin','Integrate REST APIs','Fix crashes and performance issues','Write instrumented tests'],['Published or demo Android app'],8),
J('j10','Cloud Support Associate','Cumulus Care','Hyderabad','On-site','Full-time',0,'Diploma',['AWS','Linux','Networking','SQL'],['Python','Git'],'Help customers diagnose problems with cloud-hosted applications.',['Troubleshoot customer issues','Read logs and query databases','Document solutions','Escalate complex cases'],['Foundational cloud and networking knowledge'],2),
J('j11','Product Analyst','Marigold Commerce','Remote','Remote','Full-time',1,'Bachelor',['SQL','Excel','Analytics','Python'],['Tableau','Statistics'],'Measure how shoppers use the product and recommend improvements.',['Define and track product metrics','Run A/B test analyses','Write SQL for funnels and cohorts','Share insights with product managers'],['Quantitative degree','Curiosity about user behaviour'],11),
J('j12','Data Engineer','Riverbend Data','Bengaluru','Hybrid','Full-time',2,'Bachelor',['Python','SQL','ETL','Spark','AWS'],['Kafka','Docker','Terraform'],'Build the pipelines that feed analytics and ML for a mobility company.',['Build and monitor ETL pipelines','Optimise Spark jobs','Model warehouse tables','Improve data quality checks'],['2+ years with data pipelines'],10),
J('j13','Cybersecurity Analyst','Ironleaf Security','Delhi','On-site','Full-time',1,'Bachelor',['Networking','Linux','Security','Python'],['Git'],'Monitor alerts and investigate suspicious activity for managed security clients.',['Triage security alerts','Investigate incidents','Write detection scripts in Python','Report to clients'],['Understanding of network protocols'],12),
J('j14','Software Engineer Intern','Sproutwave','Hyderabad','On-site','Internship',0,'Any',['Java','Data Structures','Algorithms','Git'],['Python','SQL'],'Six-month internship building internal tools alongside a mentor.',['Implement small features','Fix bugs','Write tests','Present your work at demo day'],['Currently pursuing or recently completed a degree'],1)];}
const POOL=[
{id:'c1',name:'Ananya Rao',email:'ananya.rao@example.com',phone:'+91 90000 00001',location:'Hyderabad',qualification:'B.Tech',specialization:'Computer Science',college:'Sample Institute of Technology',gradYear:'2025',role:'Frontend Developer',exp:1.5,skills:['JavaScript','React','HTML','CSS','Git','TypeScript','Tailwind'],projects:['Portfolio site built with React and Tailwind','Task board using JavaScript and local storage'],certs:['Responsive Web Design (sample)']},
{id:'c2',name:'Rohan Mehta',email:'rohan.mehta@example.com',phone:'+91 90000 00002',location:'Bengaluru',qualification:'B.E.',specialization:'Information Technology',college:'Sample College of Engineering',gradYear:'2022',role:'Java Developer',exp:2.5,skills:['Java','Spring Boot','SQL','REST','Git','Docker','AWS'],projects:['Library management REST API in Spring Boot with SQL','Dockerised inventory service deployed on AWS'],certs:[]},
{id:'c3',name:'Priya Nair',email:'priya.nair@example.com',phone:'+91 90000 00003',location:'Hyderabad',qualification:'B.Sc',specialization:'Statistics',college:'Sample University',gradYear:'2024',role:'Data Analyst',exp:1,skills:['SQL','Excel','Python','Tableau','Statistics'],projects:['Sales dashboard in Tableau','Churn analysis with Python and SQL'],certs:['Data Analytics Certificate (sample)']},
{id:'c4',name:'Karthik Reddy',email:'karthik.reddy@example.com',phone:'+91 90000 00004',location:'Pune',qualification:'B.Tech',specialization:'Computer Science',college:'Sample Institute of Technology',gradYear:'2025',role:'Full Stack Developer',exp:0.5,skills:['JavaScript','Node.js','React','MongoDB','REST','Git'],projects:['Chat app with React, Node.js and MongoDB','REST API for a booking system'],certs:[]},
{id:'c5',name:'Sara Khan',email:'sara.khan@example.com',phone:'+91 90000 00005',location:'Remote',qualification:'M.Tech',specialization:'Artificial Intelligence',college:'Sample University',gradYear:'2022',role:'Machine Learning Engineer',exp:2,skills:['Python','Machine Learning','TensorFlow','Pandas','SQL','Statistics'],projects:['Movie recommender using TensorFlow and Pandas','Fraud detection model with Python'],certs:['TensorFlow Developer (sample)']},
{id:'c6',name:'Vikram Singh',email:'vikram.singh@example.com',phone:'+91 90000 00006',location:'Bengaluru',qualification:'B.E.',specialization:'Electronics',college:'Sample College of Engineering',gradYear:'2020',role:'DevOps Engineer',exp:3.5,skills:['Linux','Docker','Kubernetes','CI/CD','AWS','Git','Jenkins'],projects:['Kubernetes deployment pipeline with Jenkins on AWS'],certs:['AWS Cloud Practitioner (sample)']},
{id:'c7',name:'Meera Iyer',email:'meera.iyer@example.com',phone:'+91 90000 00007',location:'Mumbai',qualification:'B.Des',specialization:'Interaction Design',college:'Sample Design School',gradYear:'2023',role:'UI/UX Designer',exp:2,skills:['Figma','UX Research','Prototyping','HTML','CSS'],projects:['Redesign of a clinic booking flow with user interviews in Figma'],certs:[]},
{id:'c8',name:'Arjun Das',email:'arjun.das@example.com',phone:'',location:'',qualification:'',specialization:'',college:'',gradYear:'',role:'',exp:null,skills:['Python','Java'],projects:[],certs:[]}];
const blankProfile=()=>({name:'',email:'',phone:'',location:'',qualification:'',specialization:'',college:'',gradYear:'',role:'',exp:'',skills:[],projects:'',certs:'',prefRole:'',prefLocation:'',workMode:'',empType:'',resume:null});
const defaults=()=>({v:1,mode:'candidate',signedIn:false,profile:blankProfile(),jobs:seedJobs(),saved:[],viewed:[],apps:[],shortlist:{},notes:[],act:[],progress:{},learn:{},practice:{},target:'',theme:'system'});
let S;
function load(){try{const r=localStorage.getItem(KEY);if(r){const o=JSON.parse(r);if(o&&o.v===1)return Object.assign(defaults(),o)}}catch(e){}return defaults();}
const BE={online:false,timer:null};
function save(){const j=JSON.stringify(S);try{localStorage.setItem(KEY,j)}catch(e){}if(BE.online)scheduleSync(j)}
function scheduleSync(j){clearTimeout(BE.timer);BE.timer=setTimeout(()=>{fetch('api/state',{method:'PUT',headers:{'Content-Type':'application/json'},body:j}).then(r=>{if(!r.ok)throw new Error('save')}).catch(()=>{BE.online=false;toast('Server not reachable — changes are saved in this browser only',true)})},400)}
async function bootBackend(){try{const h=await fetch('api/health',{cache:'no-store'});if(!h.ok)return;const o=await h.json();if(!o||o.status!=='ok')return;
 const r=await fetch('api/state',{cache:'no-store'});const srv=r.ok?await r.json():{};BE.online=true;
 if(srv&&srv.v===1){S=Object.assign(defaults(),srv);applyTheme();render(true)}else{save();if(PAGE==='settings')render(true)}}catch(e){}}
S=load();
const applyTheme=()=>{const r=document.documentElement;if(S.theme==='system')r.removeAttribute('data-theme');else r.setAttribute('data-theme',S.theme)};applyTheme();
const jobById=id=>S.jobs.find(j=>j.id===id);
const activeJobs=()=>S.jobs.filter(j=>j.published);
function asCand(p){return{skills:p.skills||[],role:p.role,prefRole:p.prefRole,projects:p.projects,certs:p.certs,exp:p.exp,qualification:p.qualification}}
const myCand=()=>asCand(S.profile);
const myMatch=j=>scoreMatch(myCand(),j);
function rankedJobs(list){const items=list.map(j=>({key:j.id,j,m:myMatch(j)}));return topK(items,items.length,rankCmp);}
// profile completion
const PFIELDS=[['name','Full name',10],['email','Email',10],['phone','Phone',5],['location','Location',5],['qualification','Qualification',8],['specialization','Specialization',5],['college','College or university',5],['gradYear','Graduation year',5],['role','Current or desired role',8],['exp','Experience',6],['skills','Skills',15],['projects','Projects',8],['certs','Certifications',3],['workMode','Work mode',4],['prefLocation','Preferred location',3]];
function filled(p,k){const v=p[k];return Array.isArray(v)?v.length>0:String(v??'').trim()!==''}
function completion(p){const tot=PFIELDS.reduce((a,f)=>a+f[2],0),got=PFIELDS.reduce((a,f)=>a+(filled(p,f[0])?f[2]:0),0);return Math.round(100*got/tot)}
const missingFields=p=>PFIELDS.filter(f=>!filled(p,f[0])).map(f=>f[1]);
// ------------- helpers
const fmtDate=t=>new Date(t).toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'});
const ago=t=>{const d=Math.floor((Date.now()-t)/day);return d<=0?'Today':d===1?'Yesterday':d+' days ago'};
const initials=n=>(n||'?').split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase();
const maskEmail=e=>e?e.replace(/^(.).*(@.*)$/,'$1•••$2'):'';
function note(aud,text){S.notes.unshift({id:uid(),aud,text,t:Date.now(),read:false});S.notes=S.notes.slice(0,60)}
function act(aud,text){S.act.unshift({aud,text,t:Date.now()});S.act=S.act.slice(0,40)}
function toast(msg,bad){const t=document.createElement('div');t.className='toast'+(bad?' bad':'');t.innerHTML=`${ic(bad?'alert':'check')}<span>${esc(msg)}</span>`;$('#toasts').appendChild(t);setTimeout(()=>t.remove(),3600)}
function ring(score,size=120,stroke=10,sub='compatibility'){
 if(score==null)return`<div class="ring" style="width:${size}px;height:${size}px"><svg width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${(size-stroke)/2}" fill="none" stroke="var(--line)" stroke-width="${stroke}"/></svg><div class="n"><b>—</b><i>no score yet</i></div></div>`;
 const r=(size-stroke)/2,c=2*Math.PI*r,col=score>=75?'var(--lime)':score>=55?'var(--ink)':'var(--coral)';
 return`<div class="ring" style="width:${size}px;height:${size}px" role="img" aria-label="${score}% ${sub}"><svg width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="var(--line)" stroke-width="${stroke}"/><circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="${col}" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c*(1-score/100)}"/></svg><div class="n"><b>${score}%</b>${sub?`<i>${sub}</i>`:''}</div></div>`}
const barCls=v=>v>=75?'lime':v>=55?'':'coral';
function breakdown(m){return m.comps.map(c=>`<div class="brow ${c.known?'':'na'}"><span>${esc(c.label)}${c.known?'':' <span class="xs muted">(not scored)</span>'}</span><div class="bar ${c.known?barCls(c.v):''}" role="progressbar" aria-valuenow="${c.known?c.v:0}" aria-valuemin="0" aria-valuemax="100" aria-label="${esc(c.label)}"><i style="width:${c.known?c.v:0}%"></i></div><span class="v">${c.known?c.v+'%':'—'}</span></div>`).join('')}
const chips=(arr,cls='',icon='')=>arr.length?`<div class="chips">${arr.map(s=>`<span class="chip ${cls}">${icon?ic(icon,12):''}${esc(s)}</span>`).join('')}</div>`:'<span class="muted small">None</span>';
const badge=m=>{const b=bandOf(m.score);return`<span class="badge ${b.cls}">${esc(b.label)}</span>`};
const statusBadge=s=>`<span class="badge s-${s.replace(' ','-')}">${esc(s)}</span>`;
function empty(icon,title,text,btn){return`<div class="empty">${ic(icon,28)}<h3>${esc(title)}</h3><p>${esc(text)}</p>${btn||''}</div>`}
const NEXT={Applied:['Under Review','Shortlisted','Rejected'],'Under Review':['Shortlisted','Rejected'],Shortlisted:['Interview','Rejected'],Interview:['Selected','Rejected'],Selected:[],Rejected:[]};
// ------------- chrome
const CNAV=[['dashboard.html','Dashboard'],['profile.html','Profile'],['jobs.html','Find jobs'],['saved.html','Saved & applications'],['skills.html','Skills & roadmap'],['interview.html','Interview prep']];
const RNAV=[['recruiter.html','Overview'],['recruiter-jobs.html','Jobs'],['recruiter-apps.html','Applications']];
const unread=aud=>S.notes.filter(n=>n.aud===aud&&!n.read).length;
function header(route,pub){
 const rec=PAGE.startsWith('recruiter')&&!pub,items=pub?[['index.html','Home'],['jobs.html','Find jobs'],['recruiter.html','For recruiters'],['index.html#features','Features']]:rec?RNAV:CNAV;
 const cur=h=>h.split(/[?#]/)[0]===(ACTIVE[PAGE]||PAGE+'.html')&&!h.includes('#');
 const aud=rec?'recruiter':'candidate',n=unread(aud);
 return`<header class="hdr"><div class="wrap"><a class="brand" href="index.html"><span class="mark" aria-hidden="true"></span>TalentMatch</a>
 <button class="iconbtn menu-btn" data-a="menu" aria-label="Open menu" aria-expanded="false">${ic('menu',20)}</button>
 <nav class="nav" aria-label="Main">${items.map(([h,t])=>`<a href="${h}" ${cur(h)?'aria-current="page"':''}>${t}</a>`).join('')}</nav>
 <div class="hdr-r">${pub?`<button class="btn btn-line btn-sm hide-m" data-a="signin">${S.signedIn?'Account':'Sign in'}</button><a class="btn btn-primary btn-sm" href="dashboard.html">${S.signedIn?'Open app':'Get started'}</a>`:`
 <div class="seg hide-m" role="group" aria-label="Switch workspace"><a href="dashboard.html" ${!rec?'aria-current="true"':''}>Candidate</a><a href="recruiter.html" ${rec?'aria-current="true"':''}>Recruiter</a></div>
 <button class="iconbtn" data-a="notes" aria-label="Notifications${n?`, ${n} unread`:''}">${ic('bell',18)}${n?`<span class="dot">${n}</span>`:''}</button>
 <a class="iconbtn" href="settings.html" aria-label="Settings">${ic('sliders',18)}</a>`}</div></div></header>`}
function footer(){return`<footer class="footer"><div class="wrap grid g4"><div><div class="brand" style="color:#F6F5F0"><span class="mark" aria-hidden="true"></span>TalentMatch</div><p class="small muted" style="margin-top:10px">Skills meet opportunity.</p></div>
<div class="stack small"><b>Candidates</b><div><a href="jobs.html">Find jobs</a></div><div><a href="profile.html">Upload resume</a></div><div><a href="skills.html">Skill gaps</a></div></div>
<div class="stack small"><b>Recruiters</b><div><a href="recruiter.html">Overview</a></div><div><a href="recruiter-job-form.html">Post a job</a></div><div><a href="recruiter-jobs.html">Rank candidates</a></div></div>
<div class="stack small"><b>Contact</b><div class="muted">hello@talentmatch.example</div><div class="muted">+00 000 000 0000</div><div class="muted">Placeholder details</div></div></div></footer>`}
// ------------- landing
const DEMO_C={skills:['JavaScript','React','HTML','CSS','Git'],role:'Frontend Developer',projects:['Portfolio built with React and CSS','Task tracker in JavaScript'],exp:1,qualification:'B.Tech',certs:[]};
function landing(){
 const demoJob=seedJobs()[0],m=scoreMatch(DEMO_C,demoJob);
 const ranked=topK(POOL.map(c=>({key:c.id,c,m:scoreMatch(c,demoJob)})),3,rankCmp);
 const gap=scoreMatch({...DEMO_C,skills:['JavaScript','HTML','Git'],role:'Web Developer'},demoJob);
 return`<main id="main" tabindex="-1" style="padding:0">
 <section class="hero"><div class="blob1"></div><div class="blob2"></div><div class="wrap"><div>
 <div class="label">YOUR NEXT OPPORTUNITY STARTS HERE</div><h1 style="margin-top:14px">Skills meet opportunity.</h1>
 <p class="lead">Upload your resume and TalentMatch builds your profile, ranks jobs by how well they fit, and shows exactly which skills to build next.</p>
 <div class="row"><a class="btn btn-primary" href="jobs.html">Explore opportunities</a><a class="btn btn-line" href="recruiter.html">I’m hiring</a></div></div>
 <div class="compose" aria-label="Product preview with sample data">
  <div class="card c-res tight"><div class="row between"><b class="small">Resume profile</b><span class="pill-sample">Sample data</span></div><div class="row" style="margin:12px 0"><span class="avatar">AR</span><div><b>Ananya Rao</b><div class="xs muted">Frontend Developer · Hyderabad</div></div></div>${chips(['JavaScript','React','CSS','Git'])}<p class="xs muted" style="margin-top:10px">Parsed from resume · 4 fields to review</p></div>
  <div class="card c-job tight"><div class="row between"><b class="small">Frontend Developer</b>${badge(m)}</div><div class="xs muted" style="margin:4px 0 10px">Northwind Labs · Hybrid</div>${chips(demoJob.req.slice(0,4),'ok','check')}<div class="xs muted" style="margin-top:10px">Missing: ${esc(m.missingReq.join(', ')||'none')}</div></div>
  <div class="card c-score tight"><div class="row"><div>${ring(m.score,84,8,'')}</div><div><b class="small">Compatibility</b><div class="xs muted">Calculated live from sample data with the same engine used in the app</div></div></div></div></div></div></section>
 <section class="lsec" id="how"><div class="wrap"><h2>How TalentMatch works</h2><div class="steps">
 <div class="step"><b>Step 1</b><h3>Upload your resume</h3><p class="small muted">PDF or DOCX, up to 5 MB. Resume files themselves are never stored.</p></div>
 <div class="step"><b>Step 2</b><h3>Review your profile</h3><p class="small muted">Check what we found, edit anything, and decide which changes to keep.</p></div>
 <div class="step"><b>Step 3</b><h3>See ranked jobs</h3><p class="small muted">Every score shows matched skills, gaps, and how complete your data is.</p></div>
 <div class="step"><b>Step 4</b><h3>Close the gaps</h3><p class="small muted">Get a roadmap and interview practice built around the job you pick.</p></div></div></div></section>
 <section class="lsec" id="features"><div class="wrap"><div class="grid g2" style="align-items:center;gap:48px"><div><h2>Scores you can explain</h2><p class="lead">Each match weighs required skills, preferred skills, role and project relevance, experience, and education. Missing information is left out and flagged, never counted against you.</p>
 <details class="exp" style="margin-top:20px"><summary>How is this score calculated?</summary><p class="small muted" style="margin-top:8px">Required skills 50%, preferred skills 15%, role and project relevance 15%, experience 10%, education and certifications 10%. Weights are redistributed across the factors we have data for. A score estimates alignment with a job’s stated requirements. It does not predict hiring outcomes.</p></details></div>
 <div class="card"><div class="row between"><b>Frontend Developer · sample</b><span class="pill-sample">Sample data</span></div><div class="row" style="gap:24px;margin:18px 0">${ring(m.score,110,10)}<div class="stack"><div>${badge(m)}</div><div class="small muted">Data used: ${m.confidence}%</div></div></div><div class="stack">${breakdown(m)}</div></div></div></div></section>
 <section class="lsec"><div class="wrap"><div class="grid g2" style="gap:24px"><div class="card"><div class="row between"><h3>Skill-gap preview</h3><span class="pill-sample">Sample data</span></div><p class="small muted" style="margin:6px 0 14px">Candidate lists JavaScript, HTML, Git. Target: Frontend Developer.</p><div class="lbl">Matched</div>${chips(gap.matchedReq,'ok','check')}<div class="lbl" style="margin-top:14px">Missing</div>${chips(gap.missingReq,'miss','x')}</div>
 <div class="card"><div class="row between"><h3>Recruiter ranking preview</h3><span class="pill-sample">Sample data</span></div><div class="list" style="margin-top:14px">${ranked.map(r=>`<div class="row between"><div class="row"><span class="avatar">${initials(r.c.name)}</span><div><b class="small">${esc(r.c.name.split(' ')[0])} ${esc(r.c.name.split(' ')[1][0])}.</b><div class="xs muted">${esc(r.c.role||'Role not provided')}</div></div></div><div class="row">${badge(r.m)}<b class="sora">${r.m.score==null?'—':r.m.score+'%'}</b></div></div>`).join('')}</div></div></div></div></section>
 <section class="lsec"><div class="wrap grid g2" style="gap:24px"><div class="card flat"><h3>For candidates</h3><ul class="clean muted" style="margin-top:10px"><li>Resume to profile in seconds, with every change reviewed by you</li><li>Honest scores that show what drives them</li><li>A roadmap and practice questions tied to your target job</li></ul><a class="btn btn-primary" style="margin-top:16px" href="profile.html">Upload a resume</a></div>
 <div class="card flat"><h3>For recruiters</h3><ul class="clean muted" style="margin-top:10px"><li>Post a role and see candidates ranked by fit</li><li>Matched and missing skills on every candidate</li><li>Track applications from applied to selected</li></ul><a class="btn btn-line" style="margin-top:16px" href="recruiter-job-form.html">Post a job</a></div></div></section>
 <section class="lsec" style="border:0"><div class="wrap"><div class="cta-band"><div><h2>Find the role that fits your skills.</h2><p style="margin-top:8px">Start with your resume. It takes a minute.</p></div><a class="btn btn-primary" href="profile.html">Get started</a></div></div></section>${footer()}</main>`}
// ------------- candidate: dashboard
function dashboard(){
 const p=S.profile,pct=completion(p),ranked=rankedJobs(activeJobs()),rec=ranked.filter(r=>r.m.score!=null&&r.m.score>=55),scored=ranked.filter(r=>r.m.score!=null);
 const avg=scored.length?Math.round(scored.reduce((a,r)=>a+r.m.score,0)/scored.length):null,top=ranked.slice(0,4);
 const gapMap={};ranked.filter(r=>r.m.score!=null).slice(0,6).forEach(r=>r.m.missingReq.forEach(s=>gapMap[s]=(gapMap[s]||0)+1));
 const gaps=Object.entries(gapMap).sort((a,b)=>b[1]-a[1]).slice(0,6);
 const byStatus={};S.apps.forEach(a=>byStatus[a.status]=(byStatus[a.status]||0)+1);
 const mine=S.act.filter(a=>a.aud==='candidate').slice(0,5);
 const recent=S.viewed.map(jobById).filter(Boolean).slice(0,3);
 return`<main id="main" tabindex="-1"><div class="wrap">
 <div class="page-h"><div><h1 style="font-size:clamp(26px,4vw,38px)">${p.name?`Hello, ${esc(p.name.split(' ')[0])}`:'Welcome to TalentMatch'}</h1><p class="muted">${pct<100?'Finish your profile to get more accurate job matches.':'Your profile is complete. Matches use all available information.'}</p></div>
 <a class="btn btn-lime" href="profile.html">${ic('upload')} ${p.resume?'Replace resume':'Upload resume'}</a></div>
 <div class="card row between" style="margin-bottom:16px;gap:20px"><div style="flex:1;min-width:240px"><div class="row between"><b>Profile completion</b><b class="sora">${pct}%</b></div><div class="bar lime" style="margin:10px 0" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100" aria-label="Profile completion"><i style="width:${pct}%"></i></div><p class="small muted">${pct<100?`Missing: ${esc(missingFields(p).slice(0,4).join(', '))}${missingFields(p).length>4?'…':''}`:'All fields filled'}</p></div>
 <div class="row"><span class="badge">${ic(p.resume?'check':'file',13)} ${p.resume?`Resume: ${esc(p.resume.name)}`:'No resume uploaded'}</span></div></div>
 <div class="grid g4" style="margin-bottom:16px">
 <div class="card stat"><span>Recommended jobs</span><b>${rec.length}</b><span class="xs">Match score 55% or higher</span></div>
 <div class="card stat"><span>Saved jobs</span><b>${S.saved.filter(id=>jobById(id)).length}</b></div>
 <div class="card stat"><span>Applications</span><b>${S.apps.length}</b></div>
 <div class="card stat"><span>Average compatibility</span><b>${avg==null?'—':avg+'%'}</b><span class="xs">${avg==null?'Add skills to see this':`Across ${scored.length} open jobs`}</span></div></div>
 <div class="split"><div class="stack-lg">
 <section><div class="sec-h"><h3>Top recommended jobs</h3><a href="jobs.html" class="small">See all jobs</a></div>
 ${scored.length?`<div class="stack">${top.map(r=>jobCard(r.j,r.m)).join('')}</div>`:empty('file','No matches yet','Upload a resume or add your skills and we’ll rank every open job for you.',`<a class="btn btn-primary" href="profile.html">Build your profile</a>`)}</section>
 <section><div class="sec-h"><h3>Recently viewed</h3></div>${recent.length?`<div class="card list">${recent.map(j=>`<div class="row between"><div><a href="job.html?id=${j.id}"><b>${esc(j.title)}</b></a><div class="small muted">${esc(j.company)} · ${esc(j.location)}</div></div>${S.saved.includes(j.id)?'<span class="badge">Saved</span>':''}</div>`).join('')}</div>`:`<div class="card flat muted small">Jobs you open will appear here.</div>`}</section></div>
 <div class="stack-lg"><section class="card"><h3>Application status</h3>${S.apps.length?`<div class="list" style="margin-top:12px">${Object.keys(NEXT).filter(s=>byStatus[s]).map(s=>`<div class="row between">${statusBadge(s)}<b>${byStatus[s]}</b></div>`).join('')}</div>`:`<p class="small muted" style="margin-top:8px">You haven’t applied yet. <a href="jobs.html">Browse jobs</a>.</p>`}</section>
 <section class="card"><h3>Skill-gap summary</h3>${gaps.length?`<p class="small muted" style="margin:6px 0 12px">Missing across your top matches</p><div class="chips">${gaps.map(([s,n])=>`<span class="chip miss">${ic('x',12)}${esc(s)} <span class="muted">×${n}</span></span>`).join('')}</div><a class="btn btn-line btn-sm" style="margin-top:14px" href="skills.html">Open skill-gap analysis</a>`:`<p class="small muted" style="margin-top:8px">${scored.length?'No recurring gaps in your top matches.':'Add skills to see your gaps.'}</p>`}</section>
 <section class="card"><h3>Skills to learn next</h3>${gaps.length?`<ul class="clean small" style="margin-top:10px">${gaps.slice(0,3).map(([s])=>`<li>${esc(s)}: ${esc(skillInfo(s,{title:'target'}).action)}</li>`).join('')}</ul>`:`<p class="small muted" style="margin-top:8px">Recommendations appear once your profile has skills.</p>`}</section>
 <section class="card"><h3>Recent activity</h3>${mine.length?`<div class="list small" style="margin-top:10px">${mine.map(a=>`<div>${esc(a.text)}<div class="xs muted">${ago(a.t)}</div></div>`).join('')}</div>`:`<p class="small muted" style="margin-top:8px">Saving your profile, applying, or bookmarking jobs will show up here.</p>`}</section></div></div></div></main>`}
// ------------- job card
function jobCard(j,m){const saved=S.saved.includes(j.id),applied=S.apps.some(a=>a.jobId===j.id);
 return`<article class="card jcard"><div style="flex:1;min-width:0"><div class="row" style="gap:8px;margin-bottom:4px"><h3><a href="job.html?id=${j.id}">${esc(j.title)}</a></h3>${j.sample?'<span class="pill-sample">Sample listing</span>':''}${applied?'<span class="badge">Applied</span>':''}</div>
 <div class="meta"><span>${ic('briefcase',14)}${esc(j.company)}</span><span>${ic('pin',14)}${esc(j.location)}</span><span>${esc(j.mode)}</span><span>${esc(j.type)}</span><span>${ic('clock',14)}${j.expMin?j.expMin+'+ yrs':'Fresher friendly'}</span><span>${ago(j.posted)}</span></div>
 <div style="margin:12px 0">${m?chipsMatched(j,m):chips(j.req.slice(0,5))}</div>
 <div class="row"><a class="btn btn-primary btn-sm" href="job.html?id=${j.id}">View details</a><button class="btn btn-line btn-sm" data-a="save-job" data-id="${j.id}" aria-pressed="${saved}">${ic('bookmark',14)} ${saved?'Saved':'Save job'}</button></div></div>
 <div class="jscore">${m&&m.score!=null?`${ring(m.score,84,8,'')}${badge(m)}`:`<span class="xs muted" style="max-width:110px">${m?'Add skills to see your match':''}</span>`}</div></article>`}
function chipsMatched(j,m){if(m.score==null)return chips(j.req.slice(0,5));const a=m.matchedReq.slice(0,4).map(s=>`<span class="chip ok">${ic('check',12)}${esc(s)}</span>`),b=m.missingReq.slice(0,3).map(s=>`<span class="chip miss">${ic('x',12)}${esc(s)}</span>`);return`<div class="chips">${a.join('')}${b.join('')}</div>`}
// ------------- jobs discovery
const JF0={q:'',loc:'',mode:'',type:'',exp:'',skill:'',sort:'match'},JF=Object.assign({},JF0);try{Object.assign(JF,JSON.parse(sessionStorage.getItem('tm.jf')||'{}'))}catch(e){}
const saveJF=()=>{try{sessionStorage.setItem('tm.jf',JSON.stringify(JF))}catch(e){}};
function allSkillNames(){const s=new Set();S.jobs.forEach(j=>[...j.req,...(j.pref||[])].forEach(x=>s.add(disp(canon(x)))));return[...s].sort()}
function filteredJobs(){
 let l=activeJobs().filter(j=>{
  const q=JF.q.trim().toLowerCase(),loc=JF.loc.trim().toLowerCase();
  if(q&&!(j.title+' '+j.company+' '+j.req.join(' ')+' '+(j.pref||[]).join(' ')+' '+j.desc).toLowerCase().includes(q))return false;
  if(loc&&!(j.location.toLowerCase().includes(loc)||(j.mode==='Remote'&&'remote'.includes(loc))))return false;
  if(JF.mode&&j.mode!==JF.mode)return false;if(JF.type&&j.type!==JF.type)return false;
  if(JF.exp!==''&&j.expMin>+JF.exp)return false;
  if(JF.skill.trim()){const k=canon(JF.skill);if(![...j.req,...(j.pref||[])].map(canon).includes(k))return false}
  return true});
 const items=l.map(j=>({key:j.id,j,m:myMatch(j)}));
 if(JF.sort==='match')return topK(items,items.length,rankCmp);
 const cmp={new:(a,b)=>a.j.posted-b.j.posted,title:(a,b)=>b.j.title.localeCompare(a.j.title),exp:(a,b)=>b.j.expMin-a.j.expMin}[JF.sort];
 return topK(items,items.length,cmp);}
function jobResults(){const r=filteredJobs();return`<p class="small muted" style="margin-bottom:12px" aria-live="polite">${r.length} job${r.length===1?'':'s'} found${S.profile.skills.length?'':' · Add skills to your profile to see match scores'}</p>${r.length?`<div class="stack">${r.map(x=>jobCard(x.j,x.m)).join('')}</div>`:empty('search','No jobs match these filters','Try removing a filter or searching a broader keyword.',`<button class="btn btn-line" data-a="clear-filters">Clear filters</button>`)}`}
function jobsPage(){const sel=(n,opts)=>`<select class="inp" data-i="jf" name="${n}" aria-label="${n}">${opts.map(([v,t])=>`<option value="${v}" ${JF[n]===v?'selected':''}>${t}</option>`).join('')}</select>`;
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><div><h1 style="font-size:clamp(26px,4vw,38px)">Find jobs</h1><p class="muted">Open roles ranked by how well your profile fits.</p></div></div>
 <form class="card" data-f="search" style="margin-bottom:20px"><div class="grid" style="grid-template-columns:2fr 1.4fr auto;gap:12px;align-items:end"><div class="field"><label for="q">Job title or keyword</label><input id="q" class="inp" data-i="jf" name="q" value="${esc(JF.q)}" placeholder="e.g. React, data analyst"></div><div class="field"><label for="loc">Location</label><input id="loc" class="inp" data-i="jf" name="loc" value="${esc(JF.loc)}" placeholder="City or Remote"></div><button class="btn btn-primary" type="submit">${ic('search')} Search</button></div>
 <div class="grid g4" style="margin-top:14px"><div class="field"><label>Work mode</label>${sel('mode',[['','Any'],['On-site','On-site'],['Hybrid','Hybrid'],['Remote','Remote']])}</div><div class="field"><label>Employment type</label>${sel('type',[['','Any'],['Full-time','Full-time'],['Internship','Internship'],['Part-time','Part-time'],['Contract','Contract']])}</div><div class="field"><label>Experience required</label>${sel('exp',[['','Any'],['0','Fresher (0 yrs)'],['2','Up to 2 yrs'],['5','Up to 5 yrs']])}</div><div class="field"><label for="skill">Skill</label><input id="skill" class="inp" list="skl" data-i="jf" name="skill" value="${esc(JF.skill)}" placeholder="e.g. Docker"><datalist id="skl">${allSkillNames().map(s=>`<option value="${esc(s)}">`).join('')}</datalist></div></div>
 <div class="row between" style="margin-top:14px"><div class="field" style="flex-direction:row;align-items:center;gap:10px"><label for="sort">Sort by</label><select id="sort" class="inp" style="width:auto" data-i="jf" name="sort"><option value="match" ${JF.sort==='match'?'selected':''}>Best match</option><option value="new" ${JF.sort==='new'?'selected':''}>Newest</option><option value="title" ${JF.sort==='title'?'selected':''}>Title A–Z</option><option value="exp" ${JF.sort==='exp'?'selected':''}>Experience (lowest first)</option></select></div><button type="button" class="link small" data-a="clear-filters">Clear filters</button></div></form>
 <div id="job-results">${jobResults()}</div></div></main>`}
// ------------- job details
function jobDetail(id){const j=jobById(id);if(!j)return`<main id="main" tabindex="-1"><div class="wrap">${empty('alert','Job not found','This listing may have been removed.',`<a class="btn btn-primary" href="jobs.html">Back to jobs</a>`)}</div></main>`;
 if(!S.viewed.includes(id)){S.viewed.unshift(id);S.viewed=S.viewed.slice(0,8);save()}
 const m=myMatch(j),app=S.apps.find(a=>a.jobId===id),saved=S.saved.includes(id),ready=S.profile.name&&S.profile.email&&S.profile.skills.length;
 return`<main id="main" tabindex="-1"><div class="wrap"><p class="small" style="margin-bottom:14px"><a href="jobs.html">← All jobs</a></p>
 <div class="split"><div class="stack-lg"><section class="card"><div class="row" style="gap:8px"><h1 style="font-size:clamp(24px,3.4vw,34px)">${esc(j.title)}</h1>${j.sample?'<span class="pill-sample">Sample listing</span>':''}</div><div class="meta" style="margin-top:10px"><span>${ic('briefcase',14)}${esc(j.company)}</span><span>${ic('pin',14)}${esc(j.location)}</span><span>${esc(j.mode)}</span><span>${esc(j.type)}</span><span>${j.expMin?j.expMin+'+ years':'Freshers welcome'}</span><span>Posted ${fmtDate(j.posted)}</span></div>
 <h3 style="margin-top:22px">About the role</h3><p class="muted" style="margin-top:6px">${esc(j.desc)}</p>
 <h3 style="margin-top:22px">Responsibilities</h3><ul class="clean muted">${(j.resp||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul>
 <h3 style="margin-top:22px">Qualifications</h3><ul class="clean muted">${(j.quals||[]).map(x=>`<li>${esc(x)}</li>`).join('')}<li>Education: ${esc(j.edu==='Any'?'No specific degree required':j.edu+' level')}</li></ul>
 <h3 style="margin-top:22px">Required skills</h3><div style="margin-top:8px">${m.score!=null?`<div class="chips">${j.req.map(s=>{const ok=m.matchedReq.includes(disp(canon(s)));return`<span class="chip ${ok?'ok':'miss'}">${ic(ok?'check':'x',12)}${esc(s)}</span>`}).join('')}</div>`:chips(j.req)}</div>
 ${(j.pref||[]).length?`<h3 style="margin-top:22px">Preferred skills</h3><div style="margin-top:8px">${chips(j.pref)}</div>`:''}
 <h3 style="margin-top:22px">How to apply</h3><p class="muted" style="margin-top:6px">${esc(j.apply||'Apply through TalentMatch.')}</p></section></div>
 <aside class="stack" style="position:sticky;top:84px"><section class="card"><div class="row" style="gap:16px">${ring(m.score,104,10,'')}<div class="stack"><div>${badge(m)}</div>${m.score!=null?`<div class="small muted">Data used: ${m.confidence}%</div>`:''}</div></div>
 ${m.score==null?`<p class="small muted" style="margin-top:14px">${esc(m.reason)} <a href="profile.html">Open profile</a></p>`:`<div class="stack" style="margin-top:18px">${breakdown(m)}</div><ul class="clean small" style="margin-top:16px">${m.explain.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>${m.notes.map(n=>`<p class="xs muted" style="margin-top:8px">${esc(n)}</p>`).join('')}${m.matchedPref.length?`<p class="small" style="margin-top:10px"><b>Preferred skills you have:</b> ${esc(m.matchedPref.join(', '))}</p>`:''}${m.relProjects.length?`<p class="small" style="margin-top:10px"><b>Relevant project:</b> ${esc(m.relProjects[0])}</p>`:''}`}
 <details class="exp" style="margin-top:16px"><summary>How is this score calculated?</summary><p class="small muted" style="margin-top:8px">Required skills 50%, preferred skills 15%, role and project relevance 15%, experience 10%, education and certifications 10%. Skills are compared after normalising names (for example, JS and JavaScript are the same). Factors with no data are left out and the remaining weights are rescaled. The score estimates alignment with the stated requirements. It is not a prediction or guarantee of being hired.</p></details></section>
 <section class="card stack">${app?`<div class="row between"><b>Application</b>${statusBadge(app.status)}</div><p class="small muted">Applied ${fmtDate(app.date)}</p>`:`<button class="btn btn-primary" data-a="apply" data-id="${j.id}" style="width:100%">${ic('send')} Apply</button>${ready?'':`<p class="small muted">${ic('alert',13)} Add your name, email, and skills in your <a href="profile.html">profile</a> first.</p>`}`}
 <button class="btn btn-line" data-a="save-job" data-id="${j.id}" style="width:100%" aria-pressed="${saved}">${ic('bookmark')} ${saved?'Saved':'Save job'}</button><a class="btn btn-line" href="skills.html" data-a="target" data-id="${j.id}" style="width:100%">${ic('target')} Analyse skill gap</a></section></aside></div></div></main>`}
// ------------- saved + applications
let TAB={saved:'saved',skills:'gap',rec:'jobs'};
function savedPage(){const sv=S.saved.map(jobById).filter(Boolean);
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><h1 style="font-size:clamp(26px,4vw,38px)">Saved & applications</h1></div>
 <div class="tabs" role="tablist"><button role="tab" data-a="tab" data-k="saved" data-v="saved" aria-selected="${TAB.saved==='saved'}">Saved jobs (${sv.length})</button><button role="tab" data-a="tab" data-k="saved" data-v="apps" aria-selected="${TAB.saved==='apps'}">Applications (${S.apps.length})</button></div>
 ${TAB.saved==='saved'?(sv.length?`<div class="stack">${sv.map(j=>jobCard(j,myMatch(j))).join('')}</div>`:empty('bookmark','No saved jobs','Save jobs you want to come back to and they’ll be listed here.',`<a class="btn btn-primary" href="jobs.html">Browse jobs</a>`)):
 (S.apps.length?`<div class="card tscroll"><table class="table"><thead><tr><th>Job</th><th>Company</th><th>Applied</th><th>Match</th><th>Status</th></tr></thead><tbody>${S.apps.map(a=>{const j=jobById(a.jobId);if(!j)return'';const m=myMatch(j);return`<tr><td><a href="job.html?id=${j.id}"><b>${esc(j.title)}</b></a></td><td>${esc(j.company)}</td><td>${fmtDate(a.date)}</td><td>${m.score==null?'—':m.score+'%'}</td><td>${statusBadge(a.status)}</td></tr>`}).join('')}</tbody></table></div>`:empty('send','No applications yet','When you apply, the status of each application is tracked here and updates as recruiters respond.',`<a class="btn btn-primary" href="jobs.html">Find jobs to apply to</a>`))}</div></main>`}
// ------------- profile + resume
let D={draft:null,errors:{},fromRes:new Set(),busy:false,diff:null};
function ensureDraft(){if(!D.draft)D.draft=JSON.parse(JSON.stringify(S.profile))}
const dirty=()=>JSON.stringify(D.draft)!==JSON.stringify(S.profile);
function fld(id,label,type='text',opts={}){const v=D.draft[id]??'',e=D.errors[id];
 return`<div class="field ${opts.full?'full':''}"><label for="p-${id}">${label}${opts.req?' *':''}</label><input id="p-${id}" class="inp ${D.fromRes.has(id)?'fromres':''}" data-i="pf" name="${id}" type="${type}" value="${esc(v)}" ${e?'aria-invalid="true"':''} ${e?`aria-describedby="e-${id}"`:''} ${opts.ph?`placeholder="${opts.ph}"`:''} ${opts.attrs||''}>${e?`<span class="err" id="e-${id}">${esc(e)}</span>`:''}${D.fromRes.has(id)?'<span class="hint">Filled from resume — please review</span>':''}</div>`}
function skillChips(){return(D.draft.skills||[]).map((s,i)=>`<span class="chip ${D.fromRes.has('skills')?'ok':''}">${esc(s)}<button type="button" data-a="skill-rm" data-i="${i}" aria-label="Remove ${esc(s)}">${ic('x',12)}</button></span>`).join('')||'<span class="muted small">No skills yet</span>'}
function profilePage(){ensureDraft();const d=D.draft,pct=completion(d);
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><div><h1 style="font-size:clamp(26px,4vw,38px)">Your profile</h1><p class="muted">Upload a resume to fill this in automatically, then review and save.</p></div><div class="card tight" style="min-width:220px"><div class="row between small"><b>Completion</b><b id="pct">${pct}%</b></div><div class="bar lime" style="margin-top:8px"><i id="pctbar" style="width:${pct}%"></i></div></div></div>
 <section class="card" style="margin-bottom:16px"><div class="drop" id="drop"><div class="big">${ic('upload',22)}</div><h3>Upload your resume</h3><p class="muted small" style="margin:6px 0 14px">PDF, DOC, or DOCX · up to 5 MB · Only the profile fields you save are stored</p>
 <input type="file" id="file" accept=".pdf,.doc,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword" hidden><div class="row" style="justify-content:center"><button type="button" class="btn btn-primary" data-a="choose">Choose file</button><button type="button" class="btn btn-line" data-a="paste">Paste resume text</button><button type="button" class="btn btn-line" data-a="sample-resume">Try a sample resume</button></div>
 <div class="prog" id="prog" hidden></div></div>${d.resume?`<p class="small muted" style="margin-top:12px">${ic('file',14)} Current resume: <b>${esc(d.resume.name)}</b> · ${esc(d.resume.size)} · processed ${fmtDate(d.resume.date)}</p>`:`<p class="small muted" style="margin-top:12px">No resume uploaded yet.</p>`}</section>
 <form class="stack-lg" data-f="profile" novalidate>
 <section class="card"><fieldset><legend>Personal information</legend><div class="fgrid">${fld('name','Full name','text',{req:1,attrs:'autocomplete="name"'})}${fld('email','Email','email',{req:1,attrs:'autocomplete="email"'})}${fld('phone','Phone','tel',{attrs:'autocomplete="tel"'})}${fld('location','Location')}</div></fieldset></section>
 <section class="card"><fieldset><legend>Education</legend><div class="fgrid">${fld('qualification','Qualification',"text",{ph:'e.g. B.Tech'})}${fld('specialization','Specialization')}${fld('college','College or university')}${fld('gradYear','Graduation year','number',{attrs:'min="1980" max="2040"'})}</div></fieldset></section>
 <section class="card"><fieldset><legend>Professional information</legend><div class="fgrid">${fld('role','Current or desired role')}${fld('exp','Years of experience','number',{attrs:'min="0" max="50" step="0.5"'})}
 <div class="field full"><label for="skill-in">Skills</label><div class="chips" id="skill-chips" style="margin-bottom:6px">${skillChips()}</div><input id="skill-in" class="inp ${D.fromRes.has('skills')?'fromres':''}" placeholder="Type a skill and press Enter" data-i="skill-in" enterkeyhint="done"><span class="hint">Extracted skills are what you claim, not verified. Remove or add as needed.</span></div>
 <div class="field full"><label for="p-projects">Projects <span class="muted">(one per line)</span></label><textarea id="p-projects" class="inp ${D.fromRes.has('projects')?'fromres':''}" data-i="pf" name="projects" rows="4">${esc(d.projects)}</textarea></div>
 <div class="field full"><label for="p-certs">Certifications <span class="muted">(one per line)</span></label><textarea id="p-certs" class="inp ${D.fromRes.has('certs')?'fromres':''}" data-i="pf" name="certs" rows="3">${esc(d.certs)}</textarea></div></div></fieldset></section>
 <section class="card"><fieldset><legend>Job preferences</legend><div class="fgrid">${fld('prefRole','Preferred role')}${fld('prefLocation','Preferred location')}
 <div class="field"><label for="p-workMode">Work mode</label><select id="p-workMode" class="inp" data-i="pf" name="workMode">${['','On-site','Hybrid','Remote'].map(v=>`<option value="${v}" ${d.workMode===v?'selected':''}>${v||'No preference'}</option>`).join('')}</select></div>
 <div class="field"><label for="p-empType">Employment type</label><select id="p-empType" class="inp" data-i="pf" name="empType">${['','Full-time','Internship','Part-time','Contract'].map(v=>`<option value="${v}" ${d.empType===v?'selected':''}>${v||'No preference'}</option>`).join('')}</select></div></div></fieldset></section>
 <div class="row"><button class="btn btn-primary" type="submit">Save profile</button><button type="button" class="btn btn-line" data-a="profile-cancel">Cancel changes</button><span class="small muted" id="dirty">${dirty()?'You have unsaved changes':''}</span></div></form></div></main>`}
function validateProfile(d){const e={};if(!d.name.trim())e.name='Enter your full name.';if(!d.email.trim())e.email='Enter your email address.';else if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email.trim()))e.email='Enter a valid email, like name@example.com.';
 if(d.phone&&d.phone.replace(/\D/g,'').length<8)e.phone='Phone number looks too short.';if(d.gradYear&&(+d.gradYear<1980||+d.gradYear>2040))e.gradYear='Enter a year between 1980 and 2040.';if(d.exp!==''&&(isNaN(+d.exp)||+d.exp<0||+d.exp>50))e.exp='Enter years between 0 and 50.';return e}
const FLABEL={name:'Full name',email:'Email',phone:'Phone',location:'Location',qualification:'Qualification',specialization:'Specialization',college:'College or university',gradYear:'Graduation year',role:'Role',exp:'Years of experience',skills:'Skills',projects:'Projects',certs:'Certifications'};
// upload pipeline
const PDFJS='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',PDFW='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',MAMMOTH='https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js';
const loaded={};
function loadScript(src){return loaded[src]||(loaded[src]=new Promise((res,rej)=>{const s=document.createElement('script');s.src=src;s.onload=res;s.onerror=()=>{delete loaded[src];rej(new Error('script'))};document.head.appendChild(s)}))}
const withTimeout=(p,ms,msg)=>Promise.race([p,new Promise((_,r)=>setTimeout(()=>r(new Error(msg||'timeout')),ms))]);
async function extractPdf(buf){await loadScript(PDFJS);const lib=window.pdfjsLib;lib.GlobalWorkerOptions.workerSrc=PDFW;const doc=await lib.getDocument({data:buf}).promise;const out=[];
 for(let p=1;p<=Math.min(doc.numPages,8);p++){const pg=await doc.getPage(p),tc=await pg.getTextContent(),rows=[];
  for(const it of tc.items){if(!it.str||!it.str.trim())continue;const y=Math.round(it.transform[5]);let r=rows.find(r=>Math.abs(r.y-y)<=3);if(!r){r={y,items:[]};rows.push(r)}r.items.push({x:it.transform[4],s:it.str})}
  rows.sort((a,b)=>b.y-a.y);rows.forEach(r=>{r.items.sort((a,b)=>a.x-b.x);out.push(r.items.map(i=>i.s).join(' ').replace(/\s+/g,' ').trim())})}
 return out.join('\n')}
async function extractViaServer(file){const r=await fetch('api/resume/extract?name='+encodeURIComponent(file.name),{method:'POST',body:file});if(!r.ok)throw new Error('server');const o=await r.json();return o.text}
async function extractDocx(buf){await loadScript(MAMMOTH);const r=await window.mammoth.extractRawText({arrayBuffer:buf});return r.value.replace(/\n{2,}/g,'\n')}
const fmtSize=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
function prog(html,state){const el=$('#prog');if(!el)return;el.hidden=!html;el.innerHTML=html||'';el.dataset.state=state||''}
function progBar(label,pct,bad){return`<div class="row between small"><span>${label}</span><span>${pct==null?'':pct+'%'}</span></div><div class="bar ${bad?'coral':'lime'}" style="margin-top:6px" role="progressbar" aria-label="Resume processing" ${pct==null?'':`aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"`}><i style="width:${pct==null?100:pct}%"></i></div>`}
function failUpload(msg){D.busy=false;prog(`<div class="notice" role="alert">${ic('alert',16)}<div><b>Couldn’t process this resume.</b><div>${esc(msg)}</div><div style="margin-top:8px"><button type="button" class="link" data-a="paste">Paste your resume text instead</button></div></div></div>`,'error');}
async function handleFile(file){
 if(D.busy)return;ensureDraft();D.busy=true;
 try{
  const ext=(file.name.split('.').pop()||'').toLowerCase();
  if(!['pdf','doc','docx'].includes(ext))return failUpload(`“${file.name}” isn’t a supported type. Upload a PDF, DOC, or DOCX file.`);
  if(file.size>5*1048576)return failUpload(`This file is ${fmtSize(file.size)}. The limit is 5 MB.`);
  if(file.size<100)return failUpload('This file appears to be empty.');
  prog(`<div class="small"><b>${esc(file.name)}</b> · ${fmtSize(file.size)}</div>`+progBar('Reading file',5),'busy');
  const buf=await new Promise((res,rej)=>{const r=new FileReader();r.onprogress=e=>{if(e.lengthComputable)prog(`<div class="small"><b>${esc(file.name)}</b> · ${fmtSize(file.size)}</div>`+progBar('Reading file',Math.round(e.loaded/e.total*40)),'busy')};r.onload=()=>res(r.result);r.onerror=()=>rej(new Error('read'));r.readAsArrayBuffer(file)});
  const h=new Uint8Array(buf.slice(0,8)),isPdf=h[0]===0x25&&h[1]===0x50&&h[2]===0x44&&h[3]===0x46,isZip=h[0]===0x50&&h[1]===0x4B,isOle=h[0]===0xD0&&h[1]===0xCF;
  if((ext==='pdf'&&!isPdf)||(ext==='docx'&&!isZip)||(ext==='doc'&&!isOle&&!isZip))return failUpload('The file contents don’t match its extension, so it can’t be a valid resume document.');
  if(ext==='doc'&&isOle)return failUpload('Legacy .doc files can’t be read in the browser. Save the file as DOCX or PDF, or paste the text.');
  const bar=l=>prog(`<div class="small"><b>${esc(file.name)}</b> · ${fmtSize(file.size)}</div>`+progBar(l,null),'busy');
  bar('Extracting text…');
  let text;try{
   if(BE.online&&ext==='docx'){try{text=await withTimeout(extractViaServer(file),25000,'timeout')}catch(e){if(e.message==='timeout')throw e;text=null}}
   if(!text)text=await withTimeout(ext==='pdf'?extractPdf(buf):extractDocx(buf),25000,'timeout');
  }catch(e){return failUpload(e.message==='timeout'?'Reading the file took too long. Try a smaller file or paste the text.':'The file couldn’t be read. It may be corrupted, password-protected, or the document reader failed to load. Check your connection or paste the text.')}
  if(!text||text.replace(/\s/g,'').length<40)return failUpload('No readable text was found. Scanned or image-only resumes aren’t supported — upload a text-based file or paste the text.');
  bar('Finding profile fields…');
  const res=parseResume(text);
  if(!res.count)return failUpload('We read the file but couldn’t find recognisable profile fields.');
  D.busy=false;prog('', '');openDiff(res,{name:file.name,size:fmtSize(file.size),date:Date.now()});
 }catch(e){console.error('[resume]',e.message);failUpload('Something went wrong while reading the file.')}
}
function openDiff(res,meta){ensureDraft();const d=D.draft,rows=[];
 for(const k of Object.keys(FLABEL)){let nv=res.fields[k];if(nv==null)continue;
  if(k==='skills'){const have=new Set((d.skills||[]).map(canon)),add=nv.filter(s=>!have.has(canon(s)));if(!add.length)continue;rows.push({k,label:'Skills to add',cur:(d.skills||[]).join(', ')||'—',nv:add,show:add.join(', '),def:true});continue}
  if(k==='projects'||k==='certs'){const cur=d[k].trim(),joined=nv.join('\n');if(cur===joined)continue;rows.push({k,label:FLABEL[k],cur:cur?cur.split('\n').length+' item(s)':'—',nv:joined,show:nv.length+' item(s) found',def:!cur});continue}
  const cur=String(d[k]??'').trim();if(cur===String(nv).trim())continue;rows.push({k,label:FLABEL[k],cur:cur||'—',nv:String(nv),show:String(nv),def:!cur});}
 D.diff={rows,meta};
 if(!rows.length){toast('Resume read — nothing new to add to your profile');applyDiffMeta(meta);return}
 modal(`<h3>Review what we found</h3><p class="small muted" style="margin:6px 0 16px">${res.count} field${res.count===1?'':'s'} found in <b>${esc(meta.name)}</b>. Fields you’ve already filled are unchecked so nothing is overwritten unless you choose.</p>
 <form data-f="diff"><div class="list">${rows.map((r,i)=>`<label class="row" style="align-items:flex-start;gap:12px;cursor:pointer"><input type="checkbox" name="r${i}" ${r.def?'checked':''} style="margin-top:4px;width:18px;height:18px"><span style="flex:1"><b class="small">${esc(r.label)}</b><span class="small" style="display:block;overflow-wrap:anywhere">${esc(r.show.length>200?r.show.slice(0,200)+'…':r.show)}</span>${r.cur!=='—'&&r.k!=='skills'?`<span class="xs muted" style="display:block">Currently: ${esc(r.cur)}</span>`:''}</span></label>`).join('')}</div>
 <div class="row" style="margin-top:20px;justify-content:flex-end"><button type="button" class="btn btn-line" data-a="close">Cancel</button><button type="submit" class="btn btn-primary">Apply selected</button></div></form>`,'Review resume data');}
function applyDiffMeta(meta){D.draft.resume=meta;render(true)}
function applyDiff(form){const {rows,meta}=D.diff;let n=0;D.fromRes=new Set();
 rows.forEach((r,i)=>{if(!form.elements['r'+i]||!form.elements['r'+i].checked)return;n++;
  if(r.k==='skills'){D.draft.skills=[...(D.draft.skills||[]),...r.nv]}else if(r.k==='projects'||r.k==='certs'){D.draft[r.k]=r.nv}else D.draft[r.k]=r.nv;D.fromRes.add(r.k)});
 D.draft.resume=meta;D.errors={};closeModal();render(true);
 if(n){toast(`${n} field${n===1?'':'s'} filled from your resume. Review and save.`);note('candidate','Resume processed: '+meta.name)}else toast('No changes applied');
 const el=$('#p-name');if(el)el.scrollIntoView({block:'center',behavior:'smooth'})}
const SAMPLE=`ANANYA RAO
Frontend Developer
ananya.rao@example.com | +91 98765 43210 | Hyderabad, Telangana

SUMMARY
Frontend developer with 1.5 years of experience building responsive web apps.

SKILLS
Languages: JavaScript, TypeScript, HTML, CSS
Frameworks: React, Tailwind
Tools: Git, Figma, Jest

EDUCATION
B.Tech in Computer Science, Sample Institute of Technology
2021 - 2025 | CGPA 8.4

PROJECTS
• Portfolio Site: built with React and Tailwind, deployed on GitHub Pages
• Task Board: drag-and-drop kanban using JavaScript and REST API with Node.js

CERTIFICATIONS
• Responsive Web Design (sample certificate)
• JavaScript Algorithms and Data Structures (sample certificate)`;
// ------------- skill gap + roadmap
const INFO={react:['Most modern front-end roles build UIs with React components.','Build a small app using components, state, and props.','Rebuild one page of your portfolio as a React app.'],javascript:['It is the core language of web front ends.','Practise DOM manipulation, async code, and array methods.','Create an interactive to-do list without a framework.'],sql:['Nearly every data and backend role queries relational data.','Practise joins, grouping, and subqueries on a sample database.','Analyse a public dataset using only SQL queries.'],python:['Python is used for data work, automation, and ML.','Work through functions, data structures, and file handling.','Write a script that cleans a CSV and summarises it.'],docker:['Containers make deployments repeatable.','Learn images, containers, and docker-compose basics.','Containerise one of your existing projects.'],kubernetes:['It runs containers at scale in production.','Learn pods, deployments, and services on a local cluster.','Deploy a two-service app to a local Kubernetes cluster.'],aws:['Many teams host and operate services on AWS.','Learn core services: compute, storage, and IAM.','Deploy a small web app on AWS free tier.'],git:['Teams collaborate through version control.','Practise branching, merging, and pull requests.','Contribute to a small open-source repo.'],'spring boot':['It is the standard framework for Java services.','Build a CRUD service with controllers and repositories.','Create a REST API for a library catalogue.'],rest:['REST APIs connect front ends and back ends.','Learn resources, HTTP verbs, and status codes.','Design and document a small REST API.'],tableau:['Dashboards are how analysts share findings.','Build charts and a dashboard from a public dataset.','Publish a dashboard on a topic you care about.'],excel:['Analysts rely on spreadsheets daily.','Practise pivot tables, lookups, and charts.','Build a budget tracker with formulas.'],'machine learning':['It is central to ML engineering roles.','Learn supervised learning and model evaluation.','Train and evaluate a classifier on a public dataset.'],typescript:['Typed JavaScript is common in larger codebases.','Convert a small JS project to TypeScript.','Add types to your portfolio project.'],mongodb:['Document databases are common in JS stacks.','Learn CRUD, schemas, and indexes.','Add MongoDB storage to a small API.'],'node.js':['It powers JavaScript back ends.','Build routes and middleware with Node.js.','Create an API with authentication.'],figma:['Design hand-off happens in Figma.','Practise components, auto-layout, and prototyping.','Redesign one screen of an app you use.'],linux:['Servers and CI run on Linux.','Learn the shell, permissions, and processes.','Set up a small server and automate a task with a script.'],'ci/cd':['Automated pipelines ship code safely.','Set up a pipeline that tests and builds on every push.','Add CI to one of your repositories.']};
function skillInfo(s,job){const k=canon(s),i=INFO[k];return i?{why:i[0],action:i[1],project:i[2]}:{why:`${job.title} listings ask for ${s}.`,action:`Follow an introductory course or the official documentation for ${s}, then practise with small exercises.`,project:`Add ${s} to one of your existing projects and note what changed.`}}
const LST=['Not started','Learning','Practising','Comfortable'];
function gapList(job,m){const req=m.missingReq.map((s,i)=>({s,pr:i<Math.ceil(m.missingReq.length/2)?'High':'Medium',kind:'req'}));const pf=m.missingPref.map(s=>({s,pr:'Nice to have',kind:'pref'}));return[...req,...pf]}
function targetJob(){return jobById(S.target)||rankedJobs(activeJobs())[0]?.j||activeJobs()[0]}
function skillsPage(){const jobs=activeJobs();if(!jobs.length)return`<main id="main" tabindex="-1"><div class="wrap">${empty('briefcase','No jobs to analyse','Publish a job in the recruiter workspace first.','')}</div></main>`;
 const job=targetJob(),m=myMatch(job);
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><div><h1 style="font-size:clamp(26px,4vw,38px)">Skills & roadmap</h1><p class="muted">Compare your skills with a target job, then follow a plan to close the gaps.</p></div>
 <div class="field" style="min-width:260px"><label for="tj">Target job</label><select id="tj" class="inp" data-i="target">${jobs.map(j=>`<option value="${j.id}" ${j.id===job.id?'selected':''}>${esc(j.title)} · ${esc(j.company)}</option>`).join('')}</select></div></div>
 <div class="tabs" role="tablist"><button role="tab" data-a="tab" data-k="skills" data-v="gap" aria-selected="${TAB.skills==='gap'}">Gap analysis</button><button role="tab" data-a="tab" data-k="skills" data-v="road" aria-selected="${TAB.skills==='road'}">Career roadmap</button></div>
 ${m.score==null?empty('target','Add your skills first','Skills you list in your profile are compared with this job’s requirements.',`<a class="btn btn-primary" href="profile.html">Open profile</a>`):TAB.skills==='gap'?gapView(job,m):roadView(job,m)}</div></main>`}
function gapView(job,m){const gaps=gapList(job,m);
 return`<div class="grid g3" style="margin-bottom:20px"><div class="card flat"><div class="row" style="gap:14px">${ring(m.score,84,8,'')}<div><b>${esc(job.title)}</b><div class="small muted">${esc(job.company)}</div><div style="margin-top:6px">${badge(m)}</div></div></div></div>
 <div class="card flat"><h4>Skills already matched</h4><div style="margin-top:10px">${chips(m.matchedReq,'ok','check')}</div><p class="xs muted" style="margin-top:8px">Taken from your profile. These are your claims, not verified.</p></div>
 <div class="card flat"><h4>Preferred skills you have</h4><div style="margin-top:10px">${chips(m.matchedPref,'ok','check')}</div></div></div>
 <h3 style="margin-bottom:12px">Important missing skills</h3>${gaps.length?`<div class="grid g2">${gaps.map(g=>{const inf=skillInfo(g.s,job),k=job.id+'|'+canon(g.s),st=S.learn[k]||0;return`<article class="card"><div class="row between"><h4>${esc(g.s)}</h4><span class="badge ${g.pr==='High'?'b-dev':''}">${g.pr==='Nice to have'?'Preferred':g.pr+' priority'}</span></div><p class="small muted" style="margin-top:8px"><b>Why it matters:</b> ${esc(inf.why)}</p><p class="small" style="margin-top:6px"><b>Learn:</b> ${esc(inf.action)}</p><p class="small" style="margin-top:6px"><b>Practice:</b> ${esc(inf.project)}</p>
 <div class="field" style="margin-top:12px"><label for="l-${esc(k)}" class="xs">Progress</label><select id="l-${esc(k)}" class="inp" data-i="learn" data-k="${esc(k)}">${LST.map((l,i)=>`<option value="${i}" ${i===st?'selected':''}>${l}</option>`).join('')}</select></div></article>`}).join('')}</div>`:`<div class="notice lime">${ic('check',16)}<div>You list every required and preferred skill for this job.</div></div>`}`}
function roadmap(job,m){const p=S.profile,id=k=>job.id+'|'+k,st=[];const gaps=gapList(job,m),mf=missingFields(p).filter(x=>['Projects','Experience','Qualification','Certifications','Full name','Email'].includes(x));
 st.push({t:'Immediate improvements',items:[...mf.slice(0,3).map(f=>({id:id('f-'+f),task:`Add ${f.toLowerCase()} to your profile`,why:'More complete profiles produce more reliable match scores.',pr:'High'})),{id:id('review'),task:'Review your skills list for accuracy',why:'Extracted skills are claims — remove anything you can’t discuss confidently.',pr:'Medium'}]});
 st.push({t:'Skills to learn',items:gaps.slice(0,5).map(g=>({id:id('s-'+g.s),task:`Learn ${g.s}`,why:skillInfo(g.s,job).why,pr:g.pr==='Nice to have'?'Low':g.pr,res:skillInfo(g.s,job).action}))});
 st.push({t:'Practical projects',items:(gaps.filter(g=>g.kind==='req').slice(0,2).map(g=>({id:id('p-'+g.s),task:skillInfo(g.s,job).project,why:`Shows hands-on ${g.s} experience.`,pr:'High'}))).concat(gaps.length?[]:[{id:id('p-combo'),task:`Build a project combining ${job.req.slice(0,3).join(', ')}`,why:'Demonstrates your skills together.',pr:'Medium'}])});
 st.push({t:'Portfolio & resume',items:[{id:id('r1'),task:`Tailor your resume summary to ${job.title}`,why:'Lead with the skills this role asks for.',pr:'High'},{id:id('r2'),task:'Add measurable results to two project descriptions',why:'Concrete outcomes are easier to evaluate than skill lists.',pr:'Medium'},{id:id('r3'),task:'Publish project code with a clear README',why:'Lets recruiters see your work.',pr:'Medium'}]});
 st.push({t:'Interview preparation',items:[{id:id('i1'),task:'Complete the practice questions for this job',why:'Rehearse explaining your skills and projects out loud.',pr:'Medium',link:'interview.html'}]});
 st.push({t:'Application readiness',items:[{id:id('a1'),task:`Check that high-priority gaps are in progress (current match: ${m.score}%)`,why:'You can apply at any score — this just helps you prepare.',pr:'Low'},{id:id('a2'),task:`Apply to ${job.title} at ${job.company}`,why:'Submit when you feel ready.',pr:'Low',link:'job.html?id='+job.id}]});
 return st.filter(s=>s.items.length)}
function roadView(job,m){const st=roadmap(job,m),all=st.flatMap(s=>s.items),done=all.filter(i=>S.progress[i.id]).length,pct=Math.round(100*done/all.length);
 return`<div class="card" style="margin-bottom:20px"><div class="row between"><b>Roadmap for ${esc(job.title)}</b><b class="sora">${pct}%</b></div><div class="bar lime" style="margin-top:10px" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100" aria-label="Roadmap progress"><i style="width:${pct}%"></i></div><p class="xs muted" style="margin-top:8px">${done} of ${all.length} tasks done. Generated from your current skill gaps. It doesn’t predict hiring outcomes.</p></div>
 <div class="stack-lg">${st.map(s=>`<section><h3 style="margin-bottom:10px">${s.t}</h3><div class="card list">${s.items.map(i=>`<label class="row" style="align-items:flex-start;gap:12px;cursor:pointer"><input type="checkbox" data-i="road" data-k="${esc(i.id)}" ${S.progress[i.id]?'checked':''} style="margin-top:4px;width:18px;height:18px"><span style="flex:1"><b class="small" ${S.progress[i.id]?'style="text-decoration:line-through;opacity:.6"':''}>${esc(i.task)}</b> <span class="badge" style="margin-left:6px">${i.pr}</span><span class="small muted" style="display:block">${esc(i.why)}</span>${i.res?`<span class="xs" style="display:block;margin-top:2px">Suggested: ${esc(i.res)}</span>`:''}${i.link?`<a class="xs" href="${i.link}">Open</a>`:''}</span></label>`).join('')}</div></section>`).join('')}</div>`}
// ------------- interview
function questions(job){const p=S.profile,q=[];
 q.push({id:'r1',g:'Role',t:`Walk me through your background and why you want the ${job.title} role at ${job.company}.`,h:['Start with your most relevant experience or project','Link two of your skills to this job’s requirements','Close with what you want to learn here']});
 q.push({id:'r2',g:'Role',t:`What would you focus on in your first 30 days as a ${job.title}?`,h:['Learn the codebase or tools and team workflow','Pick one small task you could finish','Ask how success is measured']});
 job.req.slice(0,6).forEach((s,i)=>q.push({id:'t'+i,g:'Technical',t:`Explain how you’d use ${s} in this role, and one trade-off you’d consider.`,h:[`Define ${s} in one sentence`,'Give a concrete example you built or studied','Mention one limitation or alternative','Connect it to a responsibility in this job']}));
 const pr=String(p.projects||'').split('\n').filter(x=>x.trim()).slice(0,3);
 if(pr.length)pr.forEach((x,i)=>q.push({id:'p'+i,g:'Project',t:`Walk me through this project: “${x.slice(0,90)}${x.length>90?'…':''}”. What was your role and what would you change?`,h:['State the problem and who it was for','Explain your specific contribution','Describe one decision and its trade-off','Say what you’d improve']}));
 else q.push({id:'p0',g:'Project',t:`Describe a project, academic or personal, where you used ${job.req[0]}.`,h:['Describe the goal','Explain what you built','Share one challenge and how you solved it']});
 ['Tell me about a time you had to learn something quickly.','Describe a disagreement in a team and how you handled it.','Tell me about a deadline you nearly missed.','Describe feedback you received and what you did with it.'].forEach((t,i)=>q.push({id:'b'+i,g:'Behavioural',t,h:['Situation: set the scene briefly','Task: what you were responsible for','Action: what you specifically did','Result: the outcome and what you learned']}));
 return q}
function interviewPage(){const jobs=activeJobs();if(!jobs.length)return`<main id="main" tabindex="-1"><div class="wrap">${empty('chat','No jobs available','Practice questions are built from a job listing.','')}</div></main>`;
 const job=targetJob(),qs=questions(job),pr=S.practice[job.id]||{},done=qs.filter(q=>pr[q.id]?.done).length,total=Object.values(S.practice).reduce((a,o)=>a+Object.values(o).filter(x=>x.done).length,0);
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><div><h1 style="font-size:clamp(26px,4vw,38px)">Interview prep</h1><p class="muted">Rule-based practice built from the job’s requirements and your profile. No AI service is connected.</p></div><div class="field" style="min-width:260px"><label for="tj">Practising for</label><select id="tj" class="inp" data-i="target">${jobs.map(j=>`<option value="${j.id}" ${j.id===job.id?'selected':''}>${esc(j.title)} · ${esc(j.company)}</option>`).join('')}</select></div></div>
 <div class="split"><div class="stack">${['Role','Technical','Project','Behavioural'].map(g=>{const l=qs.filter(q=>q.g===g);return l.length?`<section><h3 style="margin:8px 0 10px">${g} questions</h3><div class="stack">${l.map(q=>{const a=pr[q.id]||{};return`<article class="card tight"><div class="row between" style="align-items:flex-start"><b class="small" style="flex:1">${esc(q.t)}</b>${a.done?'<span class="badge b-good">Practised</span>':''}</div>
 <details class="exp" style="margin:10px 0"><summary>Hints: how to structure your answer</summary><ul class="clean small muted" style="margin-top:8px">${q.h.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="xs muted" style="margin-top:6px">These are prompts for you to fill with your own experience, not facts about you.</p></details>
 <label class="xs" for="a-${q.id}">Your answer (notes)</label><textarea id="a-${q.id}" class="inp" rows="3" data-i="ans" data-j="${job.id}" data-q="${q.id}">${esc(a.text||'')}</textarea><div class="row" style="margin-top:8px"><button class="btn btn-sm ${a.done?'btn-line':'btn-lime'}" data-a="practised" data-j="${job.id}" data-q="${q.id}">${a.done?'Mark as not practised':'Mark as practised'}</button></div></article>`}).join('')}</div></section>`:''}).join('')}</div>
 <aside class="stack"><section class="card"><h4>Progress</h4><div class="stat" style="margin-top:10px"><b>${done}/${qs.length}</b><span>practised for this job</span></div><div class="bar lime" style="margin-top:10px"><i style="width:${Math.round(100*done/qs.length)}%"></i></div><p class="xs muted" style="margin-top:10px">${total} question${total===1?'':'s'} practised in total.</p></section>
 <section class="card"><h4>Self-assessment</h4><p class="xs muted" style="margin:6px 0 10px">After each answer, check:</p>${['I gave a specific example','I named my own contribution','I stayed under two minutes','I connected it to the role','I mentioned a result or lesson'].map((x,i)=>`<label class="row small" style="gap:8px;margin:6px 0;cursor:pointer"><input type="checkbox" style="width:16px;height:16px"> ${x}</label>`).join('')}</section></aside></div></div></main>`}
// ------------- recruiter
function poolFor(job){const c=POOL.map(x=>({id:x.id,c:x,me:false}));if(S.profile.skills.length)c.push({id:'me',c:{...S.profile,id:'me',name:S.profile.name||'You'},me:true});return c.map(x=>({key:x.id,x,m:scoreMatch(asCand(x.c),job)}))}
const hasApplied=(jid,cid)=>cid==='me'&&S.apps.some(a=>a.jobId===jid);
const dispName=(c,job,me)=>me||hasApplied(job.id,c.id)?c.name:c.name.split(' ')[0]+' '+(c.name.split(' ')[1]||'')[0]+'.';
function recDash(){const jobs=activeJobs(),n=S.apps.length,pend=S.apps.filter(a=>['Applied','Under Review'].includes(a.status)).length,sl=S.apps.filter(a=>a.status==='Shortlisted').length+Object.values(S.shortlist).reduce((a,l)=>a+l.length,0);
 const act2=S.act.filter(a=>a.aud==='recruiter').slice(0,6);
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><div><h1 style="font-size:clamp(26px,4vw,38px)">Recruiter overview</h1><p class="muted">Manage listings and find the best-fit candidates.</p></div><a class="btn btn-lime" href="recruiter-job-form.html">${ic('plus')} Post a job</a></div>
 <div class="notice lime" style="margin-bottom:16px">${ic('lock',16)}<div>Demo workspace: there is no sign-in, so anyone who can open this site sees the same data. The talent pool contains sample candidates, labelled as such.</div></div>
 <div class="grid g4" style="margin-bottom:20px"><div class="card stat"><span>Active listings</span><b>${jobs.length}</b></div><div class="card stat"><span>Applications received</span><b>${n}</b></div><div class="card stat"><span>Awaiting review</span><b>${pend}</b></div><div class="card stat"><span>Shortlisted</span><b>${sl}</b></div></div>
 <div class="split"><div class="stack-lg"><section><div class="sec-h"><h3>Top-ranked candidates by job</h3></div>${jobs.length?`<div class="stack">${jobs.slice(0,4).map(j=>{const t=topK(poolFor(j).filter(x=>x.m.score!=null),3,rankCmp);return`<div class="card"><div class="row between"><div><a href="recruiter-job.html?id=${j.id}"><b>${esc(j.title)}</b></a><div class="small muted">${esc(j.company)} · ${esc(j.location)}</div></div><a class="btn btn-line btn-sm" href="recruiter-job.html?id=${j.id}">Rank all</a></div><div class="list" style="margin-top:12px">${t.map(r=>`<div class="row between"><div class="row"><span class="avatar">${initials(r.x.c.name)}</span><span class="small"><b>${esc(dispName(r.x.c,j,r.x.me))}</b>${r.x.me?'':' <span class="pill-sample">Sample</span>'}</span></div><div class="row">${badge(r.m)}<b class="sora">${r.m.score}%</b></div></div>`).join('')||'<span class="small muted">No candidates with skills yet</span>'}</div></div>`}).join('')}</div>`:empty('briefcase','No active listings','Post a job to start ranking candidates.',`<a class="btn btn-primary" href="recruiter-job-form.html">Post a job</a>`)}</section></div>
 <div class="stack-lg"><section class="card"><h3>Recent applications</h3>${S.apps.length?`<div class="list small" style="margin-top:10px">${S.apps.slice(-4).reverse().map(a=>{const j=jobById(a.jobId);return j?`<div class="row between"><div><b>${esc(S.profile.name||'Candidate')}</b><div class="xs muted">${esc(j.title)}</div></div>${statusBadge(a.status)}</div>`:''}).join('')}</div><a class="btn btn-line btn-sm" style="margin-top:12px" href="recruiter-apps.html">Manage applications</a>`:`<p class="small muted" style="margin-top:8px">Applications from candidates appear here. Switch to the candidate view and apply to a job to see one.</p>`}</section>
 <section class="card"><h3>Recent activity</h3>${act2.length?`<div class="list small" style="margin-top:10px">${act2.map(a=>`<div>${esc(a.text)}<div class="xs muted">${ago(a.t)}</div></div>`).join('')}</div>`:`<p class="small muted" style="margin-top:8px">Your job and status updates are logged here.</p>`}</section></div></div></div></main>`}
function recJobs(){return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><h1 style="font-size:clamp(26px,4vw,38px)">Job listings</h1><a class="btn btn-lime" href="recruiter-job-form.html">${ic('plus')} Post a job</a></div>
 ${S.jobs.length?`<div class="card tscroll"><table class="table"><thead><tr><th>Job</th><th>Location</th><th>Applications</th><th>Status</th><th><span class="skip">Actions</span></th></tr></thead><tbody>${S.jobs.map(j=>`<tr><td><a href="recruiter-job.html?id=${j.id}"><b>${esc(j.title)}</b></a><div class="xs muted">${esc(j.company)}${j.sample?' · sample':''}</div></td><td>${esc(j.location)} · ${esc(j.mode)}</td><td>${S.apps.filter(a=>a.jobId===j.id).length}</td><td><span class="badge ${j.published?'b-good':''}">${j.published?'Published':'Unpublished'}</span></td><td><div class="row"><a class="btn btn-line btn-sm" href="recruiter-job.html?id=${j.id}">Candidates</a><a class="btn btn-line btn-sm" href="recruiter-job-form.html?id=${j.id}">Edit</a><button class="btn btn-line btn-sm" data-a="toggle-pub" data-id="${j.id}">${j.published?'Unpublish':'Publish'}</button></div></td></tr>`).join('')}</tbody></table></div>`:empty('briefcase','No listings','Post your first job to start receiving ranked candidates.',`<a class="btn btn-primary" href="recruiter-job-form.html">Post a job</a>`)}</div></main>`}
let JE={errors:{},draft:null,id:null};
function jobForm(id){const ex=id?jobById(id):null;if(id&&!ex)return`<main id="main" tabindex="-1"><div class="wrap">${empty('alert','Listing not found','',`<a class="btn btn-primary" href="recruiter-jobs.html">Back to listings</a>`)}</div></main>`;
 if(JE.id!==(id||'new')){JE={errors:{},id:id||'new',draft:ex?{...ex,req:ex.req.join(', '),pref:(ex.pref||[]).join(', '),resp:(ex.resp||[]).join('\n'),quals:(ex.quals||[]).join('\n')}:{title:'',company:'',desc:'',resp:'',quals:'',req:'',pref:'',edu:'Bachelor',expMin:0,location:'',mode:'Hybrid',type:'Full-time',apply:''}}}
 const d=JE.draft,e=JE.errors,f=(n,l,o={})=>`<div class="field ${o.full?'full':''}"><label for="j-${n}">${l}${o.req?' *':''}</label>${o.ta?`<textarea id="j-${n}" class="inp" name="${n}" rows="${o.ta}" ${e[n]?'aria-invalid="true"':''}>${esc(d[n])}</textarea>`:o.sel?`<select id="j-${n}" class="inp" name="${n}">${o.sel.map(v=>`<option ${d[n]===v?'selected':''}>${v}</option>`).join('')}</select>`:`<input id="j-${n}" class="inp" name="${n}" type="${o.type||'text'}" value="${esc(d[n])}" ${e[n]?'aria-invalid="true"':''} ${o.ph?`placeholder="${o.ph}"`:''}>`}${e[n]?`<span class="err">${esc(e[n])}</span>`:''}${o.hint?`<span class="hint">${o.hint}</span>`:''}</div>`;
 return`<main id="main" tabindex="-1"><div class="wrap" style="max-width:820px"><p class="small" style="margin-bottom:14px"><a href="recruiter-jobs.html">← Listings</a></p><h1 style="font-size:clamp(26px,4vw,36px);margin-bottom:20px">${ex?'Edit job':'Post a job'}</h1>
 <form class="card" data-f="job" novalidate><div class="fgrid">${f('title','Job title',{req:1})}${f('company','Company',{req:1})}${f('desc','Description',{full:1,ta:4,req:1})}${f('resp','Responsibilities',{full:1,ta:3,hint:'One per line'})}${f('quals','Qualifications',{full:1,ta:3,hint:'One per line'})}${f('req','Required skills',{full:1,req:1,hint:'Comma-separated, e.g. Java, SQL, Git',ph:'Java, SQL, Git'})}${f('pref','Preferred skills',{full:1,hint:'Comma-separated'})}${f('edu','Education',{sel:['Any','Diploma','Bachelor','Master','PhD']})}${f('expMin','Minimum experience (years)',{type:'number'})}${f('location','Location',{req:1})}${f('mode','Work mode',{sel:['On-site','Hybrid','Remote']})}${f('type','Employment type',{sel:['Full-time','Part-time','Internship','Contract']})}${f('apply','Application instructions',{full:1,ta:2})}</div>
 <div class="row" style="margin-top:20px"><button class="btn btn-primary" type="submit" data-pub="1">${ex?'Save and publish':'Publish job'}</button><button class="btn btn-line" type="submit" data-pub="0">Save as draft</button><a class="btn btn-line" href="recruiter-jobs.html">Cancel</a></div></form></div></main>`}
const RF={min:0,skill:'',edu:'',exp:''};
function recRank(id){const job=jobById(id);if(!job)return`<main id="main" tabindex="-1"><div class="wrap">${empty('alert','Listing not found','',`<a class="btn btn-primary" href="recruiter-jobs.html">Back</a>`)}</div></main>`;
 return`<main id="main" tabindex="-1"><div class="wrap"><p class="small" style="margin-bottom:14px"><a href="recruiter-jobs.html">← Listings</a></p><div class="page-h"><div><h1 style="font-size:clamp(24px,3.6vw,34px)">${esc(job.title)}</h1><p class="muted">${esc(job.company)} · ${esc(job.location)} · ${esc(job.mode)} · requires ${esc(job.req.join(', '))}</p></div><span class="badge ${job.published?'b-good':''}">${job.published?'Published':'Unpublished'}</span></div>
 <div class="card" style="margin-bottom:16px"><div class="grid g4"><div class="field"><label for="rf-min">Minimum score</label><select id="rf-min" class="inp" data-i="rf" name="min">${[0,40,55,75].map(v=>`<option value="${v}" ${+RF.min===v?'selected':''}>${v?v+'% and above':'Any'}</option>`).join('')}</select></div><div class="field"><label for="rf-skill">Has skill</label><input id="rf-skill" class="inp" list="skl" data-i="rf" name="skill" value="${esc(RF.skill)}"><datalist id="skl">${allSkillNames().map(s=>`<option value="${esc(s)}">`).join('')}</datalist></div><div class="field"><label for="rf-edu">Education level</label><select id="rf-edu" class="inp" data-i="rf" name="edu">${[['','Any'],['2','Bachelor’s or higher'],['3','Master’s or higher']].map(([v,t])=>`<option value="${v}" ${RF.edu===v?'selected':''}>${t}</option>`).join('')}</select></div><div class="field"><label for="rf-exp">Min. experience</label><select id="rf-exp" class="inp" data-i="rf" name="exp">${[['','Any'],['1','1+ years'],['2','2+ years'],['3','3+ years']].map(([v,t])=>`<option value="${v}" ${RF.exp===v?'selected':''}>${t}</option>`).join('')}</select></div></div></div>
 <div id="rank-results" aria-live="polite">${rankResults(job)}</div></div></main>`}
function rankResults(job){let l=poolFor(job);
 l=l.filter(r=>{const s=r.m.score;if(+RF.min&&(s==null||s<+RF.min))return false;if(RF.skill.trim()&&!(r.x.c.skills||[]).map(canon).includes(canon(RF.skill)))return false;if(RF.edu){const e=eduRank(r.x.c.qualification);if(e==null||e<+RF.edu)return false}if(RF.exp&&!(r.x.c.exp!=null&&r.x.c.exp!==''&&+r.x.c.exp>=+RF.exp))return false;return true});
 const ranked=topK(l,l.length,rankCmp);if(!ranked.length)return empty('users','No candidates match these filters','Lower the minimum score or clear a filter.','');
 const sl=S.shortlist[job.id]||[];
 return`<p class="small muted" style="margin-bottom:12px">${ranked.length} candidate${ranked.length===1?'':'s'}, ranked by compatibility. Ties are broken by required skills matched. <span class="pill-sample">Sample</span> candidates are demo data.</p><div class="stack">${ranked.map((r,i)=>{const c=r.x.c,m=r.m,app=r.x.me?S.apps.find(a=>a.jobId===job.id):null,short=sl.includes(c.id)||(app&&app.status==='Shortlisted');
 return`<article class="card jcard"><div style="flex:1;min-width:0"><div class="row" style="gap:10px"><span class="avatar">${initials(c.name)}</span><div><b>${i+1}. ${esc(dispName(c,job,r.x.me))}</b>${r.x.me?' <span class="badge">Your profile</span>':' <span class="pill-sample">Sample</span>'}${app?` ${statusBadge(app.status)}`:''}<div class="xs muted">${esc(c.role||'Role not provided')} · ${esc(c.qualification||'Education not provided')}${c.exp!=null&&c.exp!==''?' · '+c.exp+' yrs':''}</div></div></div>
 <div style="margin:12px 0">${m.score==null?'<span class="small muted">Not enough skill data to score this candidate.</span>':`<div class="chips">${m.matchedReq.map(s=>`<span class="chip ok">${ic('check',12)}${esc(s)}</span>`).join('')}${m.missingReq.map(s=>`<span class="chip miss">${ic('x',12)}${esc(s)}</span>`).join('')}</div><p class="xs muted" style="margin-top:8px">${esc(m.explain.slice(0,2).join(' '))}${m.confidence<100?` Score uses ${m.confidence}% of available factors.`:''}</p>`}</div>
 <div class="row"><button class="btn btn-line btn-sm" data-a="view-cand" data-id="${c.id}" data-j="${job.id}">View profile</button><button class="btn btn-sm ${short?'btn-lime':'btn-primary'}" data-a="shortlist" data-id="${c.id}" data-j="${job.id}" aria-pressed="${short}">${short?'Shortlisted':'Shortlist'}</button></div></div>
 <div class="jscore">${ring(m.score,84,8,'')}${badge(m)}</div></article>`}).join('')}</div>`}
function recApps(){const rows=S.apps.map(a=>({a,j:jobById(a.jobId)})).filter(x=>x.j);
 return`<main id="main" tabindex="-1"><div class="wrap"><div class="page-h"><h1 style="font-size:clamp(26px,4vw,38px)">Applications</h1></div>${rows.length?`<div class="card tscroll"><table class="table"><thead><tr><th>Candidate</th><th>Job</th><th>Match</th><th>Applied</th><th>Status</th></tr></thead><tbody>${rows.map(({a,j})=>{const m=myMatch(j),nx=NEXT[a.status];return`<tr><td><b>${esc(S.profile.name||'Candidate')}</b><div class="xs"><button class="link" data-a="view-cand" data-id="me" data-j="${j.id}">View profile</button></div></td><td>${esc(j.title)}</td><td>${m.score==null?'—':m.score+'%'}</td><td>${fmtDate(a.date)}</td><td><div class="row">${statusBadge(a.status)}${nx.length?`<select class="inp" style="width:auto;min-height:34px;padding:4px 8px" data-i="status" data-id="${a.id}" aria-label="Update status"><option value="">Move to…</option>${nx.map(s=>`<option>${s}</option>`).join('')}</select>`:''}</div></td></tr>`}).join('')}</tbody></table></div>`:empty('send','No applications yet','Applications appear when candidates apply. In this demo, switch to the Candidate view, complete your profile, and apply to a job.',`<a class="btn btn-primary" href="dashboard.html">Go to candidate view</a>`)}</div></main>`}
// ------------- settings
function settingsPage(){return`<main id="main" tabindex="-1"><div class="wrap" style="max-width:760px"><h1 style="font-size:clamp(26px,4vw,38px);margin-bottom:20px">Settings</h1>
 <div class="stack"><section class="card"><h3>Account</h3><p class="small muted" style="margin:6px 0 14px">${S.signedIn?`Signed in as ${esc(S.profile.name||'demo user')} (local demo account).`:'You’re browsing without signing in.'}</p><button class="btn btn-line" data-a="signin">${S.signedIn?'Switch account or role':'Sign in'}</button> ${S.signedIn?'<button class="btn btn-line" data-a="signout">Sign out</button>':''}</section>
 <section class="card"><h3>Appearance</h3><div class="field" style="margin-top:12px;max-width:260px"><label for="th">Theme</label><select id="th" class="inp" data-i="theme">${[['system','Match device'],['light','Light'],['dark','Dark']].map(([v,t])=>`<option value="${v}" ${S.theme===v?'selected':''}>${t}</option>`).join('')}</select></div></section>
 <section class="card"><h3>Your data</h3><p class="small muted" style="margin:6px 0 14px">${BE.online?'Connected to the TalentMatch server: your data is saved in backend/data/state.json and mirrored in this browser.':'No backend detected: your data is saved only in this browser. Start the backend (see README) to store it on the server.'} Resume files are not kept; only the profile fields you save are.</p><div class="row"><button class="btn btn-line" data-a="export">Show my data as JSON</button><button class="btn btn-danger" data-a="reset">Reset all data</button></div></section>
 <section class="card"><h3>Limitations of this demo</h3><ul class="clean small muted" style="margin-top:8px"><li>No real authentication: candidate and recruiter views share one stored state.</li><li>Resume parsing is rule-based. DOCX is read by the Java backend when it is running, PDF in the browser. Review extracted fields before saving.</li><li>Scores estimate alignment with stated requirements and are not hiring predictions.</li></ul></section></div></div></main>`}
// ------------- modals
let lastFocus=null;
function modal(html,label){lastFocus=document.activeElement;$('#modal-root').innerHTML=`<div class="modal-bg" data-a="bg"><div class="modal" role="dialog" aria-modal="true" aria-label="${esc(label||'Dialog')}">${html}</div></div>`;const f=$('#modal-root button,#modal-root input,#modal-root textarea');if(f)f.focus()}
function closeModal(){$('#modal-root').innerHTML='';if(lastFocus&&lastFocus.focus)try{lastFocus.focus()}catch(e){}}
function notesModal(){const aud=S.mode==='recruiter'?'recruiter':'candidate',l=S.notes.filter(n=>n.aud===aud);l.forEach(n=>n.read=true);save();
 modal(`<div class="row between"><h3>Notifications</h3><button class="iconbtn" data-a="close" aria-label="Close">${ic('x')}</button></div>${l.length?`<div class="list" style="margin-top:14px">${l.slice(0,15).map(n=>`<div class="small">${esc(n.text)}<div class="xs muted">${ago(n.t)}</div></div>`).join('')}</div>`:`<div style="margin-top:14px">${empty('bell','No notifications','Updates about your profile, applications, and matches will show up here.','')}</div>`}`,'Notifications');render(true)}
function signinModal(){modal(`<h3>Sign in</h3><p class="small muted" style="margin:6px 0 16px">This is a local demo account. There are no passwords, and your details stay in this browser.</p><form data-f="signin" class="stack"><div class="field"><label for="si-n">Your name</label><input id="si-n" class="inp" name="n" value="${esc(S.profile.name)}" autocomplete="name"></div><div class="field"><label for="si-r">I am a</label><select id="si-r" class="inp" name="r"><option value="candidate" ${S.mode==='candidate'?'selected':''}>Candidate</option><option value="recruiter" ${S.mode==='recruiter'?'selected':''}>Recruiter</option></select></div><div class="row" style="justify-content:flex-end"><button type="button" class="btn btn-line" data-a="close">Cancel</button><button class="btn btn-primary" type="submit">Continue</button></div></form>`,'Sign in')}
function candModal(cid,jid){const job=jobById(jid),r=poolFor(job).find(x=>x.key===cid);if(!r)return;const c=r.x.c,applied=hasApplied(jid,cid)||r.x.me;
 modal(`<div class="row between"><div class="row"><span class="avatar">${initials(c.name)}</span><div><h3>${esc(dispName(c,job,r.x.me))}</h3><div class="small muted">${esc(c.role||'Role not provided')}</div></div></div><button class="iconbtn" data-a="close" aria-label="Close">${ic('x')}</button></div>
 <div class="row" style="margin:16px 0">${ring(r.m.score,84,8,'')}<div class="stack">${badge(r.m)}${r.m.score!=null?`<div class="xs muted">Data used: ${r.m.confidence}%</div>`:''}</div></div>${r.m.score!=null?`<div class="stack" style="margin-bottom:16px">${breakdown(r.m)}</div>`:''}
 <div class="stack small"><div><b>Education:</b> ${esc([c.qualification,c.specialization,c.college,c.gradYear].filter(Boolean).join(', ')||'Not provided')}</div><div><b>Experience:</b> ${c.exp!=null&&c.exp!==''?c.exp+' years':'Not provided'}</div><div><b>Skills:</b></div>${chips(c.skills||[])}<div><b>Projects:</b> ${(Array.isArray(c.projects)?c.projects:String(c.projects||'').split('\n').filter(Boolean)).map(esc).join('; ')||'Not provided'}</div>
 <div class="notice lime">${ic('lock',16)}<div>${applied?`<b>Contact:</b> ${esc(c.email||'—')} ${esc(c.phone||'')}`:`Contact details are shared when the candidate applies. Email on file: ${esc(maskEmail(c.email))}`}</div></div></div>`,'Candidate profile')}
// ------------- router + render
const PAGE=document.body.dataset.page||'index',QID=new URLSearchParams(location.search).get('id');
let route=PAGE;
const ACTIVE={job:'jobs.html','recruiter-job':'recruiter-jobs.html','recruiter-job-form':'recruiter-jobs.html'};
const NOTFOUND=()=>`<main id="main" tabindex="-1"><div class="wrap">${empty('alert','Page not found','That page doesn’t exist.',`<a class="btn btn-primary" href="index.html">Go home</a>`)}</div></main>`;
function view(){const T={
 index:[landing,'TalentMatch — Skills meet opportunity'],dashboard:[dashboard,'Dashboard'],profile:[profilePage,'Profile'],jobs:[jobsPage,'Find jobs'],job:[()=>jobDetail(QID),'Job details'],saved:[savedPage,'Saved & applications'],skills:[skillsPage,'Skills & roadmap'],interview:[interviewPage,'Interview prep'],settings:[settingsPage,'Settings'],
 recruiter:[recDash,'Recruiter overview'],'recruiter-jobs':[recJobs,'Job listings'],'recruiter-job':[()=>recRank(QID),'Ranked candidates'],'recruiter-job-form':[()=>jobForm(QID),QID?'Edit job':'Post a job'],'recruiter-apps':[recApps,'Applications']};
 const t=T[PAGE];if(!t)return[NOTFOUND(),'Not found'];
 if(PAGE.startsWith('recruiter'))S.mode='recruiter';else if(PAGE!=='index'&&PAGE!=='settings')S.mode='candidate';
 return[t[0](),t[1]]}
function render(keep){const [html,title]=view(),pub=PAGE==='index',y=window.scrollY;
 $('#app').innerHTML=header(PAGE,pub)+html;document.title=title+(pub?'':' · TalentMatch');
 if(keep)window.scrollTo(0,y);save()}
// ------------- actions
function toggleSave(id){const i=S.saved.indexOf(id);if(i>=0){S.saved.splice(i,1);toast('Removed from saved jobs')}else{S.saved.push(id);const j=jobById(id);act('candidate',`Saved ${j.title} at ${j.company}`);toast('Job saved')}}
function doApply(id){const j=jobById(id),p=S.profile;if(!(p.name&&p.email&&p.skills.length)){toast('Complete your profile first',true);return}
 if(S.apps.some(a=>a.jobId===id)){toast('You’ve already applied to this job',true);return}
 const m=myMatch(j);S.apps.push({id:uid(),jobId:id,status:'Applied',date:Date.now(),score:m.score});
 note('candidate',`Application submitted: ${j.title} at ${j.company}`);act('candidate',`Applied to ${j.title}`);note('recruiter',`New application for ${j.title}`);act('recruiter',`${p.name} applied to ${j.title}`);toast('Application submitted')}
function setStatus(aid,st){const a=S.apps.find(x=>x.id===aid),j=a&&jobById(a.jobId);if(!a||!NEXT[a.status].includes(st)){toast('That status change isn’t allowed',true);return}
 a.status=st;note('candidate',`${j.title} at ${j.company}: status is now ${st}`);act('recruiter',`Moved ${S.profile.name||'candidate'} to ${st} for ${j.title}`);toast('Status updated to '+st)}
function shortlist(cid,jid){const j=jobById(jid);if(cid==='me'){const a=S.apps.find(x=>x.jobId===jid);if(a){if(a.status==='Shortlisted'){toast('Already shortlisted');return}if(NEXT[a.status].includes('Shortlisted')){setStatus(a.id,'Shortlisted');return}toast('This application can’t be shortlisted from its current status',true);return}}
 const l=S.shortlist[jid]=S.shortlist[jid]||[],i=l.indexOf(cid);if(i>=0){l.splice(i,1);toast('Removed from shortlist')}else{l.push(cid);act('recruiter',`Shortlisted a candidate for ${j.title}`);toast('Candidate shortlisted')}}
function saveJob(form,publish){const d=Object.fromEntries(new FormData(form).entries()),e={};
 ['title','company','desc','location'].forEach(k=>{if(!String(d[k]||'').trim())e[k]='This field is required.'});
 const req=String(d.req||'').split(',').map(s=>s.trim()).filter(Boolean);if(!req.length)e.req='Add at least one required skill.';
 if(+d.expMin<0||isNaN(+d.expMin))e.expMin='Enter 0 or more years.';
 const dup=S.jobs.find(j=>j.id!==(JE.id==='new'?null:JE.id)&&j.title.trim().toLowerCase()===String(d.title).trim().toLowerCase()&&j.company.trim().toLowerCase()===String(d.company).trim().toLowerCase()&&j.location.trim().toLowerCase()===String(d.location).trim().toLowerCase());
 if(dup)e.title='A listing with this title, company, and location already exists.';
 JE.draft={...JE.draft,...d};JE.errors=e;
 if(Object.keys(e).length){render(true);toast('Fix the highlighted fields',true);return}
 const lines=s=>String(s||'').split('\n').map(x=>x.trim()).filter(Boolean);
 const rec={title:d.title.trim(),company:d.company.trim(),desc:d.desc.trim(),resp:lines(d.resp),quals:lines(d.quals),req,pref:String(d.pref||'').split(',').map(s=>s.trim()).filter(Boolean),edu:d.edu,expMin:+d.expMin||0,location:d.location.trim(),mode:d.mode,type:d.type,apply:d.apply.trim()||'Apply through TalentMatch.',published:publish};
 if(JE.id==='new'){const j={id:'j'+uid(),posted:Date.now(),sample:false,...rec};S.jobs.unshift(j);act('recruiter',`${publish?'Published':'Saved draft of'} ${j.title}`);if(publish){const m=myMatch(j);if(m.score!=null&&m.score>=75)note('candidate',`New strong match: ${j.title} at ${j.company} (${m.score}%)`)}toast(publish?'Job published':'Draft saved')}
 else{const j=jobById(JE.id);Object.assign(j,rec);act('recruiter',`Updated ${j.title}`);toast(publish?'Job updated and published':'Job saved as draft')}
 JE={errors:{},draft:null,id:null};location.href='recruiter-jobs.html'}
// ------------- events
const root=document;
root.addEventListener('click',e=>{
 const t=e.target.closest('[data-a]');if(!t)return;const a=t.dataset.a,id=t.dataset.id;
 if(a==='bg'){if(e.target===t)closeModal();return}
 if(a==='menu'){const n=$('.nav');const o=n.classList.toggle('open');t.setAttribute('aria-expanded',o);return}
 if(a==='close'){closeModal();return}
 if(a==='save-job'){e.preventDefault();toggleSave(id);if(route==='jobs')$('#job-results').innerHTML=jobResults();else render(true);save();return}
 if(a==='apply'){doApply(id);render(true);save();return}
 if(a==='target'){S.target=id;save();return}
 if(a==='tab'){TAB[t.dataset.k]=t.dataset.v;render(true);return}
 if(a==='clear-filters'){Object.assign(JF,JF0);saveJF();render(true);return}
 if(a==='choose'){$('#file').click();return}
 if(a==='sample-resume'){ensureDraft();const res=parseResume(SAMPLE);openDiff(res,{name:'sample-resume.txt',size:'1 KB',date:Date.now()});return}
 if(a==='paste'){modal(`<h3>Paste resume text</h3><p class="small muted" style="margin:6px 0 12px">Paste the full text of your resume. It is processed in your browser.</p><form data-f="paste"><label class="skip" for="pt">Resume text</label><textarea id="pt" class="inp" name="t" rows="12" placeholder="Name, contact details, skills, education, projects…"></textarea><div class="row" style="margin-top:14px;justify-content:flex-end"><button type="button" class="btn btn-line" data-a="close">Cancel</button><button class="btn btn-primary" type="submit">Extract details</button></div></form>`,'Paste resume text');return}
 if(a==='skill-rm'){ensureDraft();D.draft.skills.splice(+t.dataset.i,1);$('#skill-chips').innerHTML=skillChips();updDirty();return}
 if(a==='profile-cancel'){D={draft:null,errors:{},fromRes:new Set(),busy:false,diff:null};render(true);toast('Changes discarded');return}
 if(a==='practised'){const o=S.practice[t.dataset.j]=S.practice[t.dataset.j]||{},q=o[t.dataset.q]=o[t.dataset.q]||{};q.done=!q.done;if(q.done)act('candidate','Practised an interview question');render(true);save();return}
 if(a==='toggle-pub'){const j=jobById(id);j.published=!j.published;act('recruiter',`${j.published?'Published':'Unpublished'} ${j.title}`);toast(j.published?'Job published':'Job unpublished');render(true);save();return}
 if(a==='shortlist'){shortlist(id,t.dataset.j);$('#rank-results').innerHTML=rankResults(jobById(t.dataset.j));save();return}
 if(a==='view-cand'){candModal(id,t.dataset.j);return}
 if(a==='notes'){notesModal();return}
 if(a==='signin'){signinModal();return}
 if(a==='signout'){S.signedIn=false;toast('Signed out');render(true);return}
 if(a==='export'){const o={...S,jobs:S.jobs.length+' jobs'};modal(`<div class="row between"><h3>Your data</h3><button class="iconbtn" data-a="close" aria-label="Close">${ic('x')}</button></div><textarea class="inp" rows="14" readonly aria-label="Exported data" style="margin-top:12px;font-family:monospace;font-size:12px">${esc(JSON.stringify(o,null,2))}</textarea>`,'Your data');return}
 if(a==='reset'){modal(`<h3>Reset all data?</h3><p class="small muted" style="margin:8px 0 16px">This deletes your profile, saved jobs, applications, and progress from this browser. It can’t be undone.</p><div class="row" style="justify-content:flex-end"><button class="btn btn-line" data-a="close">Cancel</button><button class="btn btn-danger" data-a="reset-yes">Reset everything</button></div>`,'Confirm reset');return}
 if(a==='reset-yes'){S=defaults();D={draft:null,errors:{},fromRes:new Set(),busy:false,diff:null};JE={errors:{},draft:null,id:null};applyTheme();save();closeModal();location.href='index.html';return}
});
function updDirty(){const el=$('#dirty');if(el)el.textContent=dirty()?'You have unsaved changes':'';const pc=completion(D.draft);const a=$('#pct'),b=$('#pctbar');if(a)a.textContent=pc+'%';if(b)b.style.width=pc+'%'}
root.addEventListener('input',e=>{const t=e.target,i=t.dataset.i;if(!i)return;
 if(i==='pf'){ensureDraft();D.draft[t.name]=t.value;if(t.classList.contains('fromres')){t.classList.remove('fromres');D.fromRes.delete(t.name)}if(D.errors[t.name]){delete D.errors[t.name];t.removeAttribute('aria-invalid')}updDirty();return}
 if(i==='jf'){JF[t.name]=t.value;saveJF();const r=$('#job-results');if(r&&t.tagName!=='SELECT'||t.tagName==='SELECT'){if(r)r.innerHTML=jobResults()}return}
 if(i==='rf'){RF[t.name]=t.value;const r=$('#rank-results');if(r)r.innerHTML=rankResults(jobById(QID));return}
 if(i==='ans'){const o=S.practice[t.dataset.j]=S.practice[t.dataset.j]||{},q=o[t.dataset.q]=o[t.dataset.q]||{};q.text=t.value;save();return}});
root.addEventListener('change',e=>{const t=e.target,i=t.dataset.i;
 if(t.id==='file'){const f=t.files&&t.files[0];t.value='';if(f)handleFile(f);return}
 if(!i)return;
 if(i==='target'){S.target=t.value;render(true);return}
 if(i==='learn'){S.learn[t.dataset.k]=+t.value;save();toast('Progress saved');return}
 if(i==='road'){S.progress[t.dataset.k]=t.checked;save();render(true);return}
 if(i==='status'){if(t.value)setStatus(t.dataset.id,t.value);render(true);save();return}
 if(i==='theme'){S.theme=t.value;applyTheme();save();return}});
root.addEventListener('keydown',e=>{
 if(e.key==='Escape'&&$('#modal-root').firstChild){closeModal();return}
 if(e.target.id==='skill-in'&&(e.key==='Enter'||e.key===',')){e.preventDefault();const v=e.target.value.trim().replace(/,$/,'');if(!v)return;ensureDraft();const k=canon(v);if(!D.draft.skills.map(canon).includes(k))D.draft.skills.push(DISP[k]||v);e.target.value='';$('#skill-chips').innerHTML=skillChips();updDirty()}});
root.addEventListener('submit',e=>{const f=e.target.dataset.f;if(!f)return;e.preventDefault();
 if(f==='search'){$('#job-results').innerHTML=jobResults();return}
 if(f==='profile'){ensureDraft();const err=validateProfile(D.draft);D.errors=err;if(Object.keys(err).length){render(true);toast('Fix the highlighted fields',true);const el=$('[aria-invalid="true"]');if(el)el.focus();return}
  const first=!S.profile.name&&!S.profile.skills.length;S.profile=JSON.parse(JSON.stringify(D.draft));D.fromRes=new Set();D.draft=null;note('candidate','Profile saved');act('candidate','Saved your profile');
  const top=rankedJobs(activeJobs())[0];toast('Profile saved. Job matches updated.');if(top&&top.m.score!=null)note('candidate',`Top match now: ${top.j.title} (${top.m.score}%)`);render(true);save();return}
 if(f==='diff'){applyDiff(e.target);return}
 if(f==='paste'){const t=e.target.elements.t.value;if(t.replace(/\s/g,'').length<40){toast('Paste more of your resume text',true);return}closeModal();ensureDraft();const r=parseResume(t);if(!r.count){toast('No recognisable fields found',true);return}openDiff(r,{name:'Pasted text',size:fmtSize(t.length),date:Date.now()});return}
 if(f==='signin'){const n=e.target.elements.n.value.trim(),r=e.target.elements.r.value;S.signedIn=true;if(n&&!S.profile.name){S.profile.name=n;if(D.draft)D.draft.name=n}S.mode=r;closeModal();save();location.href=r==='recruiter'?'recruiter.html':'dashboard.html';return}
 if(f==='job'){const pub=e.submitter?e.submitter.dataset.pub==='1':true;saveJob(e.target,pub);return}});
// job form: keep draft in sync so failed validation keeps input
root.addEventListener('input',e=>{if(e.target.closest&&e.target.closest('form[data-f="job"]')&&JE.draft&&e.target.name){JE.draft[e.target.name]=e.target.value}});
// drag and drop
root.addEventListener('dragover',e=>{const d=e.target.closest&&e.target.closest('#drop');if(d){e.preventDefault();d.classList.add('over')}});
root.addEventListener('dragleave',e=>{const d=e.target.closest&&e.target.closest('#drop');if(d)d.classList.remove('over')});
root.addEventListener('drop',e=>{const d=e.target.closest&&e.target.closest('#drop');if(d){e.preventDefault();d.classList.remove('over');const f=e.dataTransfer.files&&e.dataTransfer.files[0];if(f)handleFile(f)}else if(e.dataTransfer&&e.dataTransfer.files.length)e.preventDefault()});
window.addEventListener('dragover',e=>e.preventDefault());
render();bootBackend();if(location.hash==='#features'){const f=$('#features');if(f)f.scrollIntoView()}
})();